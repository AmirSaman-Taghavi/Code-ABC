import controller.HousingController;

public class HousingHomePage {
    public static void main(String[] args) {
        HousingController housingController = new HousingController();
        housingController.control();
    }
}
