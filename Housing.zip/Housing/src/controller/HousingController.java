package controller;

import model.service.HousingServe;

public class HousingController {
    public void control() {
        HousingServe housingServe = new HousingServe();
        try {
            housingServe.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            housingServe.entity_Dependency();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            housingServe.palace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            housingServe.process();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            housingServe.realStatePerson();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            housingServe.documentation();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
