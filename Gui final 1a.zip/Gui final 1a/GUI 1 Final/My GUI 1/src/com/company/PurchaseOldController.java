package com.company;

//purchase page controller for more than five years

import com.model.entity.HousingEnti;

public class PurchaseOldController {
    HousingEnti housingEnti = new HousingEnti();
    PurchaseClassOld purchaseClassOld = new PurchaseClassOld();

    String id = purchaseClassOld.BuyerName.getText();
    String buyersName = purchaseClassOld.BuyerName.getText();
    String sellersName = purchaseClassOld.SellerName.getText();
    String buyerFatherName = purchaseClassOld.BuyerNum.getText();
    String sellerFatherName = purchaseClassOld.SellerNum.getText();
    String fiveFinalPrice = purchaseClassOld.finalprice.getText();
    String fiveLandSize = purchaseClassOld.textSize.getText();
    String water = purchaseClassOld.water.getText();
    String gas = purchaseClassOld.water.getText();
    String electricity = purchaseClassOld.electricity.getText();
    String wt;
    String gs;
    String el;

    int size;
    int codeID;
    int fPrice;
    String BName;
    String SName;
    String BFName;
    String SFName;

    public HousingEnti setHousingEnti() {

        try{
            codeID = Integer.parseInt(id);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setId_Code(purchaseClassOld.textID.getText());

        try{
            size = Integer.parseInt(fiveLandSize);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setFiveLandSize(purchaseClassOld.textSize.getText());

        try{
            fPrice = Integer.parseInt(fiveFinalPrice);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setFinalPrice(purchaseClassOld.finalprice.getText());

        try {
            BName = String.valueOf(buyersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersName(purchaseClassOld.BuyerName.getText());

        try {
            SName = String.valueOf(sellersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersName(purchaseClassOld.SellerName.getText());

        try {
            BFName = String.valueOf(buyerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersFatherName(purchaseClassOld.BuyerNum.getText());

        try {
            SFName = String.valueOf(sellerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersFatherName(purchaseClassOld.SellerNum.getText());

        try{
            wt = String.valueOf(water);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setWater(purchaseClassOld.water.getText());

        try{
            gs = String.valueOf(gas);
        }catch (StringIndexOutOfBoundsException e){}
        housingEnti.setGas(purchaseClassOld.gas.getText());

        try{
            el = String.valueOf(electricity);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setElectricity(purchaseClassOld.electricity.getText());


        return housingEnti;
    }
}
