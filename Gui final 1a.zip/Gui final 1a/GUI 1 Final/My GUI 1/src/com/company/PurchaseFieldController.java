package com.company;

//field purchase controller

import com.model.entity.HousingEnti;

public class PurchaseFieldController {
    HousingEnti housingEnti = new HousingEnti();
    PurchaseField purchaseFields = new PurchaseField();

    String id = purchaseFields.BuyerName.getText();
    String buyersName = purchaseFields.BuyerName.getText();
    String sellersName = purchaseFields.SellerName.getText();
    String buyerFatherName = purchaseFields.BuyerNum.getText();
    String sellerFatherName = purchaseFields.SellerNum.getText();
    String finalPrice = purchaseFields.finalprice.getText();
    String landSize = purchaseFields.textSize.getText();

    int size;
    int codeID;
    int fPrice;
    String BName;
    String SName;
    String BFName;
    String SFName;

    public HousingEnti setHousingEnti() {

        try{
            codeID = Integer.parseInt(id);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setId_Code(purchaseFields.textID.getText());

        try{
            size = Integer.parseInt(landSize);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setLandSize(purchaseFields.textSize.getText());

        try {
            fPrice = Integer.parseInt(finalPrice);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setFinalPrice(purchaseFields.finalprice.getText());

        try {
            BName = String.valueOf(buyersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersName(purchaseFields.BuyerName.getText());

        try {
            SName = String.valueOf(sellersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersName(purchaseFields.SellerName.getText());

        try {
            BFName = String.valueOf(buyerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersFatherName(purchaseFields.BuyerNum.getText());

        try {
            SFName = String.valueOf(sellerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersFatherName(purchaseFields.SellerNum.getText());


        return housingEnti;
    }
}