package com.company;

//more than 5 year rent controller

import com.model.entity.HousingEnti;

public class RentOldController {
    HousingEnti housingEnti = new HousingEnti();
    RentClassOld rentClassOld = new RentClassOld();

    String id = rentClassOld.BuyerName.getText();
    String buyersName = rentClassOld.BuyerName.getText();
    String sellersName = rentClassOld.SellerName.getText();
    String buyerFatherName = rentClassOld.BuyerNum.getText();
    String sellerFatherName = rentClassOld.SellerNum.getText();
    String rentPrice = rentClassOld.finalprice.getText();
    String rentSize = rentClassOld.textSize.getText();
    String water = rentClassOld.water.getText();
    String gas =rentClassOld.water.getText();
    String electricity = rentClassOld.electricity.getText();

    int size;
    int codeID;
    int rPrice;
    String BName;
    String SName;
    String BFName;
    String SFName;
    String wt;
    String gs;
    String el;

    public HousingEnti setHousingEnti() {

        try{
            codeID = Integer.parseInt(id);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setId_Code(rentClassOld.textID.getText());

        try{
            size = Integer.parseInt(rentSize);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setLandSize(rentClassOld.textSize.getText());

        try {
            rPrice = Integer.parseInt(rentPrice);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setFinalPrice(rentClassOld.finalprice.getText());

        try {
            BName = String.valueOf(buyersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersName(rentClassOld.BuyerName.getText());

        try {
            SName = String.valueOf(sellersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersName(rentClassOld.SellerName.getText());

        try {
            BFName = String.valueOf(buyerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersFatherName(rentClassOld.BuyerNum.getText());

        try {
            SFName = String.valueOf(sellerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersFatherName(rentClassOld.SellerNum.getText());

        try{
            wt = String.valueOf(water);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setWater(rentClassOld.water.getText());

        try{
            gs = String.valueOf(gas);
        }catch (StringIndexOutOfBoundsException e){}
        housingEnti.setGas(rentClassOld.gas.getText());

        try{
            el = String.valueOf(electricity);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setElectricity(rentClassOld.electricity.getText());

        return housingEnti;
    }
}
