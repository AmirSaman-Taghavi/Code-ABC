package com.company;

//rent controller

import com.model.entity.HousingEnti;

public class RentController {
    HousingEnti housingEnti = new HousingEnti();
    RentClass rentClass = new RentClass();

    String id = rentClass.BuyerName.getText();
    String buyersName = rentClass.BuyerName.getText();
    String sellersName = rentClass.SellerName.getText();
    String buyerFatherName = rentClass.BuyerNum.getText();
    String sellerFatherName = rentClass.SellerNum.getText();
    String rentPrice = rentClass.finalprice.getText();
    String rentSize = rentClass.textSize.getText();
    String water = rentClass.water.getText();
    String gas =rentClass.water.getText();
    String electricity = rentClass.electricity.getText();

    int size;
    int codeID;
    int rPrice;
    String BName;
    String SName;
    String BFName;
    String SFName;
    String wt;
    String gs;
    String el;

    public HousingEnti setHousingEnti() {

        try{
            codeID = Integer.parseInt(id);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setId_Code(rentClass.textID.getText());

        try{
            size = Integer.parseInt(rentSize);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setLandSize(rentClass.textSize.getText());

        try {
            rPrice = Integer.parseInt(rentPrice);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setFinalPrice(rentClass.finalprice.getText());

        try {
            BName = String.valueOf(buyersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersName(rentClass.BuyerName.getText());

        try {
            SName = String.valueOf(sellersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersName(rentClass.SellerName.getText());

        try {
            BFName = String.valueOf(buyerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersFatherName(rentClass.BuyerNum.getText());

        try {
            SFName = String.valueOf(sellerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersFatherName(rentClass.SellerNum.getText());

        try{
            wt = String.valueOf(water);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setWater(rentClass.water.getText());

        try{
            gs = String.valueOf(gas);
        }catch (StringIndexOutOfBoundsException e){}
        housingEnti.setGas(rentClass.gas.getText());

        try{
            el = String.valueOf(electricity);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setElectricity(rentClass.electricity.getText());

        return housingEnti;
    }

}
