package com.company;

//MyFrame Controller

import com.model.entity.HousingEnti;


public class MyFrameController  {
    HousingEnti housingEnti = new HousingEnti();
    MyFrame myFrame = new MyFrame();

    String codeValidation = myFrame.textID.getText();
    String nameValidation = myFrame.textOwnerName.getText();
    String priceValidation = myFrame.textPrice.getText();
    String sizeConfirmation = myFrame.textSize.getText();
    String dateValidation = myFrame.textDate.getText();
    String locationValidation = myFrame.textLocation.getText();

    int codeID;
    int price;
    int size;
    int time;
    String ownerName;
    String location;


    public HousingEnti setHousingEnti(){

///////checks id input
        try{
            codeID = Integer.parseInt(codeValidation);
        }
        catch (NumberFormatException e) {
        }
            housingEnti.setId_Code(myFrame.textID.getText());

//////checks name input
        try {
            ownerName = String.valueOf(nameValidation);
        }
        catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setPeople_Data(myFrame.textOwnerName.getText());

//////checks price input
        try {
            price = Integer.parseInt(priceValidation);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setFinalPrice(myFrame.textPrice.getText());

///////checks size input
        try{
            size = Integer.parseInt(sizeConfirmation);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setLand_Type(myFrame.textSize.getText());

///////checks date of recent edition input
        try{
            time = Integer.parseInt(dateValidation);
        }
        catch (NumberFormatException e){
        }
        housingEnti.setPeople_Time(myFrame.textDate.getText());

        try{
            location = String.valueOf(locationValidation);
        }
        catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setLandLocation(myFrame.textLocation.getText());


///setting
        housingEnti.setAgent_Password(null);
        housingEnti.setAgent_Password(myFrame.Password.getText());

        housingEnti.setAgentName(null);
        housingEnti.setLandSize(myFrame.Name2.getText());

        housingEnti.setAgentFatherName(null);
        housingEnti.setAgentFatherName(myFrame.FatherName.getName());

        return housingEnti;
    }
}
