package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyFrame extends JFrame implements ActionListener {
    JTable table1, table2, table3, table4, table5, table6;
//**********************************************************************************************************************
    JTextField textID, textOwnerName, textSize, textPrice, textLocation, textDate;
    JTextField textIDRR, textOwnerNameRR, textSizeRR, textPriceRR, textLocationRR, textDateRR;
    JTextField textIDGG, textOwnerNameGG, textSizeGG, textPriceGG, textLocationGG, textDateGG;
    JTextField textIDHH, textOwnerNameHH, textSizeHH, textPriceHH, textLocationHH, textDateHH;
    JTextField textIDVV, textOwnerNameVV, textSizeVV, textPriceVV, textLocationVV, textDateVV;
    JTextField textIDKK, textOwnerNameKK, textSizeKK, textPriceKK, textLocationKK, textDateKK;
//**********************************************************************************************************************
    JButton buttonAdd1, buttonUpdate1, buttonDelete1, buttonSelect1, buttonClear1;
    JButton buttonAdd2, buttonUpdate2, buttonDelete2, buttonSelect2, buttonClear2;
    JButton buttonAdd3, buttonUpdate3, buttonDelete3, buttonSelect3, buttonClear3;
    JButton buttonAdd4, buttonUpdate4, buttonDelete4, buttonSelect4, buttonClear4;
    JButton buttonAdd5, buttonUpdate5, buttonDelete5, buttonSelect5, buttonClear5;
    JButton buttonAdd6, buttonUpdate6, buttonDelete6, buttonSelect6, buttonClear6;
//**********************************************************************************************************************
    JPanel panel1,panel2,panel3,purchasePanelNew;
    JPanel panel1RR,panel2RR,panel3RR,rentPanelNew;
    JPanel panel1GG, panel2GG,panel3GG,purchasePanelOld;
    JPanel panel1HH, panel2HH,panel3HH,rentPanelOld;
    JPanel panel1VV, panel2VV,panel3VV,purchasePanelField;
    JPanel panel1KK, panel2KK,panel3KK,rentPanelField;
    JPanel panel0,panelSettings000, panelSettings111,panelSettings222, panelSettings333;
//**********************************************************************************************************************
    JTabbedPane tabbedPane, tabbedPaneNewHouses, tabbedPaneOldHouses, tabbedPaneField;
    DefaultTableModel model1, model2, model3, model4, model5, model6;
    Object[] column1, row1, column2, row2, column3, row3, row4, column4, row5, column5, row6, column6;
    JScrollPane pane1, pane2, pane3, pane4, pane5, pane6;
//**********************************************************************************************************************
    JLabel labelID1, labelOwnerName1, labelSize1, labelPrice1, labelLocation1, labelDate1;
    JLabel labelID2, labelOwnerName2, labelSize2, labelPrice2, labelLocation2, labelDate2;
    JLabel labelID3, labelOwnerName3, labelSize3, labelPrice3, labelLocation3, labelDate3;
    JLabel labelID4, labelOwnerName4, labelSize4, labelPrice4, labelLocation4, labelDate4;
    JLabel labelID5, labelOwnerName5, labelSize5, labelPrice5, labelLocation5, labelDate5;
    JLabel labelID6, labelOwnerName6, labelSize6, labelPrice6, labelLocation6, labelDate6;
//**********************************************************************************************************************
    JButton checkbutton1, checkbutton2, checkbutton3, checkbutton4;
    Checkbox water1,water2,water3,water4,electricity1,electricity2,electricity3,electricity4,gas1,gas2,gas3,gas4;
//**********************************************************************************************************************
    JButton buttonConfirm;
    JTextField UserID, Password, Name, FatherName;
    JTextField UserID2, Password2, Name2, FatherName2;
    JLabel UserIDLabel1, PasswordLabel1, NameLabel1, FatherNameLabel1;
    JLabel UserIDLabel2, PasswordLabel2, NameLabel2, FatherNameLabel2;
    MyFrame(){

        UIManager.put("TabbedPane.selected", Color.PINK);
//Settings *************************************************************************************************************
        panelSettings000 = new JPanel();
        panelSettings000.setBackground(new Color(220,140,20));
        panelSettings000.setLayout(new BorderLayout());

        panelSettings111 = new JPanel();
        panelSettings111.setBackground(new Color(220,140,20));
        panelSettings111.setLayout(new GridLayout(8,4));
        panelSettings111.setBounds(0,0,300,500);
        panelSettings000.add(panelSettings111, BorderLayout.NORTH);

        panelSettings222 = new JPanel();
        panelSettings222.setBackground(new Color(220,140,20));
        panelSettings000.add(panelSettings222, BorderLayout.CENTER);
        panelSettings222.setBounds(0,480,10,20);

        panelSettings333 = new JPanel();
        panelSettings333.setBackground(new Color(20,60,150));
        panelSettings000.add(panelSettings333, BorderLayout.SOUTH);
        panelSettings333.setBounds(0,500,300,320);

//**********************************************************************************************************************
        UserIDLabel1 = new JLabel("UserID:");
        UserIDLabel1.setBounds(10,30,100,25);
        UserIDLabel1.setFont(new Font(null,Font.BOLD,20));

        UserID= new JTextField();
        UserID.setBounds(130,30,50,25);
        UserID.setFont(new Font(null,Font.BOLD,20));
        UserID.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        PasswordLabel1 = new JLabel("Passworde:");
        PasswordLabel1.setBounds(200,30,100,25);
        PasswordLabel1.setFont(new Font(null,Font.BOLD,20));

        Password = new JTextField();
        Password.setBounds(130,30,50,25);
        Password.setFont(new Font(null,Font.BOLD,20));
        Password.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        NameLabel1 = new JLabel("Name:");
        NameLabel1.setBounds(10,20,30,25);
        NameLabel1.setFont(new Font(null,Font.BOLD,20));

        Name = new JTextField();
        Name.setBounds(10,20,30,25);
        Name.setFont(new Font(null,Font.BOLD,20));
        Name.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        FatherNameLabel1 = new JLabel("Father's Name:");
        FatherNameLabel1.setBounds(10,20,30,25);
        FatherNameLabel1.setFont(new Font(null,Font.BOLD,20));

        FatherName = new JTextField();
        FatherName.setBounds(10,20,30,25);
        FatherName.setFont(new Font(null,Font.BOLD,20));
        FatherName.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
//**********************************************************************************************************************
        UserIDLabel2 = new JLabel("New UserID:");
        UserIDLabel2.setBounds(10,20,30,25);
        UserIDLabel2.setFont(new Font(null,Font.BOLD,20));

        UserID2 = new JTextField();
        UserID2.setBounds(10,20,30,25);
        UserID2.setFont(new Font(null,Font.BOLD,20));
        UserID2.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        PasswordLabel2 = new JLabel("New Passworde:");
        PasswordLabel2.setBounds(10,20,30,25);
        PasswordLabel2.setFont(new Font(null,Font.BOLD,20));

        Password2 = new JTextField();
        Password2.setBounds(10,20,30,25);
        Password2.setFont(new Font(null,Font.BOLD,20));
        Password2.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        NameLabel2 = new JLabel("New Name:");
        NameLabel2.setBounds(10,20,30,25);
        NameLabel2.setFont(new Font(null,Font.BOLD,20));

        Name2 = new JTextField();
        Name2.setBounds(10,20,30,25);
        Name2.setFont(new Font(null,Font.BOLD,20));
        Name2.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        FatherNameLabel2 = new JLabel("New Father's Name:");
        FatherNameLabel2.setBounds(10,20,30,25);
        FatherNameLabel2.setFont(new Font(null,Font.BOLD,20));

        FatherName2 = new JTextField();
        FatherName2.setBounds(10,20,30,25);
        FatherName2.setFont(new Font(null,Font.BOLD,20));
        FatherName2.setBackground(new Color(140,140,160));
//**********************************************************************************************************************
        buttonConfirm = new JButton("Confirm");
        buttonConfirm.setBounds(10,436,290,35);
        buttonConfirm.setFocusable(false);
        buttonConfirm.setBackground(new Color(50,60,150));
        buttonConfirm.setForeground(new Color(230,130,30));

        panelSettings111.add(UserIDLabel1);
        panelSettings111.add(UserID);

        panelSettings111.add(PasswordLabel1);
        panelSettings111.add(Password);

        panelSettings111.add(NameLabel1);
        panelSettings111.add(Name);

        panelSettings111.add(FatherNameLabel1);
        panelSettings111.add(FatherName);

        panelSettings111.add(UserIDLabel2);
        panelSettings111.add(UserID2);

        panelSettings111.add(PasswordLabel2);
        panelSettings111.add(Password2);

        panelSettings111.add(NameLabel2);
        panelSettings111.add(Name2);

        panelSettings111.add(FatherNameLabel2);
        panelSettings111.add(FatherName2);

        panelSettings222.add(buttonConfirm);
//**********************************************************************************************************************
        tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPane.setForeground(new Color(170,50,40));
        tabbedPaneNewHouses = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPaneNewHouses.setForeground(new Color(170,50,40));
        tabbedPaneOldHouses = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPaneOldHouses.setForeground(new Color(170,50,40));
        tabbedPaneField = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPaneField.setForeground(new Color(170,50,40));
//**********************************************************************************************************************
        purchasePanelNew = new JPanel();
        purchasePanelNew.setBackground(new Color(220,140,20));
        purchasePanelNew.setPreferredSize(new Dimension(500,600));
        purchasePanelNew.setLayout(new BorderLayout());
        purchasePanelNew.setVisible(true);
//**********************************************************************************************************************
        rentPanelNew = new JPanel();
        rentPanelNew.setBackground(new Color(220,140,20));
        rentPanelNew.setPreferredSize((new Dimension(500,600)));
        rentPanelNew.setLayout(new BorderLayout());
        rentPanelNew.setVisible(true);
//**********************************************************************************************************************
        purchasePanelOld = new JPanel();
        purchasePanelOld.setBackground(new Color(220,140,20));
        purchasePanelOld.setPreferredSize(new Dimension(500,600));
        purchasePanelOld.setLayout(new BorderLayout());
        purchasePanelOld.setVisible(true);
//**********************************************************************************************************************
        rentPanelOld = new JPanel();
        rentPanelOld.setBackground(new Color(220,140,20));
        rentPanelOld.setPreferredSize((new Dimension(500,600)));
        rentPanelOld.setLayout(new BorderLayout());
        rentPanelOld.setVisible(true);
//**********************************************************************************************************************        
        purchasePanelField = new JPanel();
        purchasePanelField.setBackground(new Color(220,140,20));
        purchasePanelField.setPreferredSize((new Dimension(500,600)));
        purchasePanelField.setLayout(new BorderLayout());
        purchasePanelField.setVisible(true);
//**********************************************************************************************************************        
        rentPanelField = new JPanel();
        rentPanelField.setBackground(new Color(220,140,20));
        rentPanelField.setPreferredSize((new Dimension(500,600)));
        rentPanelField.setLayout(new BorderLayout());
        rentPanelField.setVisible(true);
//**********************************************************************************************************************
        panel0 = new JPanel();
        panel0.setBackground(new Color(40,60,150));
//Table1 ***************************************************************************************************************

        panel1 = new JPanel();
        table1 = new JTable();
        column1 = new Object[]{"ID", "Owner's Name", "Size", "Price", "Location", "Date of Recent Edition"};
        model1 = new DefaultTableModel();
        panel1.setBackground(new Color(220,140,30));
        panel1.setForeground(new Color(0,200,100));
        panel1.setBounds(0,0,1000,350);

        model1.setColumnIdentifiers(column1);
        table1.setModel(model1);

        table1.setBackground(new Color(200,170,150));
        table1.setForeground(new Color(40,50,120));
        table1.setSelectionBackground(new Color(180,130,150));
        table1.setGridColor(new Color(220,60,70));
        table1.setSelectionForeground(new Color(10,220,10));
        table1.setFont(new Font("Tahoma",Font.BOLD,10));
        table1.setRowHeight(30);
        table1.setAutoCreateRowSorter(true);
        table1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table1.setPreferredSize(new Dimension(700,400));


        pane1 = new JScrollPane(table1);
        panel1.setLayout(new BorderLayout());
        pane1.setForeground(new Color(10,10,200));
        pane1.setBackground(new Color(200,10,10));
        panel1.add(pane1);

        panel2 = new JPanel();
        panel2.setBackground(new Color(220,140,30));
        panel2.setForeground(new Color(0,200,100));
        panel2.setBounds(0,350,1000,200);
        panel2.setLayout(new GridLayout(6,3));

        textID = new JTextField();
        textID.setBackground(new Color(140,140,160));
        textID.setColumns(10);
        textID.setFont(new Font(null,Font.BOLD,20));

        textOwnerName = new JTextField();
        textOwnerName.setBackground(new Color(140,140,160));
        textOwnerName.setColumns(10);
        textOwnerName.setFont(new Font(null,Font.BOLD,20));

        textSize = new JTextField();
        textSize.setBackground(new Color(140,140,160));
        textSize.setColumns(10);
        textSize.setFont(new Font(null,Font.BOLD,20));

        textPrice = new JTextField();
        textPrice.setBackground(new Color(140,140,160));
        textPrice.setColumns(10);
        textPrice.setFont(new Font(null,Font.BOLD,20));

        textLocation = new JTextField();
        textLocation.setBackground(new Color(140,140,160));
        textLocation.setColumns(10);
        textLocation.setFont(new Font(null,Font.BOLD,20));

        textDate = new JTextField();
        textDate.setBackground(new Color(140,140,160));
        textDate.setColumns(10);
        textDate.setFont(new Font(null,Font.BOLD,20));

        labelID1 = new JLabel("ID");
        labelID1.setFont(new Font(null,Font.BOLD,19));
        labelID1.setForeground(new Color(40,40,40));


        labelOwnerName1 = new JLabel("Owner's Name");
        labelOwnerName1.setFont(new Font(null,Font.BOLD,19));
        labelOwnerName1.setForeground(new Color(40,40,40));


        labelSize1 = new JLabel("Size(m^2)");
        labelSize1.setFont(new Font(null,Font.BOLD,19));
        labelSize1.setForeground(new Color(40,40,40));


        labelPrice1 = new JLabel("Price(Million)");
        labelPrice1.setFont(new Font(null,Font.BOLD,19));
        labelPrice1.setForeground(new Color(40,40,40));


        labelLocation1 = new JLabel("Location");
        labelLocation1.setFont(new Font(null,Font.BOLD,19));
        labelLocation1.setForeground(new Color(40,40,40));

        labelDate1 = new JLabel("Date of Recent Edition");
        labelDate1.setFont(new Font(null,Font.BOLD,19));
        labelDate1.setForeground(new Color(40,40,40));


        row1 = new Object[5];

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int rowIndex = table1.getSelectedRow();
                long id = (long)model1.getValueAt(rowIndex, 0);
                String  OwnerName = (String)model1.getValueAt(rowIndex, 1);
                long size = (long)model1.getValueAt(rowIndex, 2);
                long price = (long)model1.getValueAt(rowIndex, 3);
                String  address = (String)model1.getValueAt(rowIndex, 4);
                String Date = (String)model1.getValueAt(rowIndex, 5);

                textID.setText(String.valueOf(id));
                textOwnerName.setText(OwnerName);
                textSize.setText(String.valueOf(size));
                textPrice.setText(String.valueOf(price));
                textLocation.setText(address);
                textDate.setText(Date);
            }
        });

        buttonAdd1 = new JButton("Add");
        buttonAdd1.setBounds(10,436,290,35);
        buttonAdd1.setFocusable(false);
        buttonAdd1.setBackground(new Color(50,60,150));
        buttonAdd1.setForeground(new Color(230,130,30));
        buttonAdd1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(textID.getText().toString().isEmpty() || textOwnerName.getText().toString().isEmpty() || textSize.getText().toString().isEmpty() || textPrice.getText().toString().isEmpty() || textLocation.getText().toString().isEmpty() || textDate.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please fill all Fields First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textID.getText().toString());
                    String OwnerName = textOwnerName.getText().toString();
                    long size = Integer.parseInt(textSize.getText().toString());
                    long price = Integer.parseInt(textPrice.getText().toString());
                    String address = textLocation.getText().toString();
                    String date = textDate.getText().toString();

                    Object[] newRow = {id, OwnerName, size, price, address, date};
                    model1.addRow(newRow);

                    textID.setText(null);
                    textOwnerName.setText(null);
                    textSize.setText(null);
                    textPrice.setText(null);
                    textLocation.setText(null);
                    textDate.setText(null);
                    JOptionPane.showMessageDialog(null,"Added Successfully");

                }
            }
        });

        buttonDelete1 = new JButton("Delete");
        buttonDelete1.setBounds(313,436,290,35);
        buttonDelete1.setFocusable(false);
        buttonDelete1.setBackground(new Color(50,60,150));
        buttonDelete1.setForeground(new Color(230,130,30));
        buttonDelete1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(table1.getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    int selection = JOptionPane.showConfirmDialog(null, "Do you want to delete this row?", "confirm", JOptionPane.YES_NO_OPTION);

                if(selection==JOptionPane.YES_OPTION){
                    model1.removeRow(table1.getSelectedRow());
                }
            }
            }
        });

        buttonUpdate1 = new JButton("Update");
        buttonUpdate1.setBounds(313,436,290,35);
        buttonUpdate1.setFocusable(false);
        buttonUpdate1.setBackground(new Color(50,60,150));
        buttonUpdate1.setForeground(new Color(230,130,30));
        buttonUpdate1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textID.getText().toString().isEmpty() || textOwnerName.getText().toString().isEmpty() || textSize.getText().toString().isEmpty() || textPrice.getText().toString().isEmpty() || textLocation.getText().toString().isEmpty()|| textDate.getText().toString().isEmpty() ) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textID.getText().toString());
                    String OwnerName = textOwnerName.getText().toString();
                    long size = Integer.parseInt(textSize.getText().toString());
                    long price = Integer.parseInt(textPrice.getText().toString());
                    String location = textOwnerName.getText().toString();
                    String date = textDate.getText().toString();

                    int row = table1.getSelectedRow();
                    model1.setValueAt(id,row,0);
                    model1.setValueAt(OwnerName,row,1);
                    model1.setValueAt(size,row,2);
                    model1.setValueAt(price,row,3);
                    model1.setValueAt(price,row,4);
                    model1.setValueAt(date,row,5);

                    textID.setText(null);
                    textOwnerName.setText(null);
                    textSize.setText(null);
                    textPrice.setText(null);
                    textLocation.setText(null);
                    textDate.setText(null);

                    JOptionPane.showMessageDialog(null,"Updated Successfully");

                }
            }

        });
    buttonSelect1 = new JButton("Purchase");
    buttonSelect1.setBounds(313,436,290,35);
    buttonSelect1.setFocusable(false);
    buttonSelect1.setBackground(new Color(50,60,150));
    buttonSelect1.setForeground(new Color(230,130,30));
    buttonSelect1.addActionListener(new ActionListener() {
        @Override
            public void actionPerformed(ActionEvent e) {
            if(textID.getText().toString().isEmpty() || textOwnerName.getText().toString().isEmpty() || textSize.getText().toString().isEmpty() ||textPrice.getText().toString().isEmpty() || textLocation.getText().toString().isEmpty()|| textDate.getText().toString().isEmpty()) {

                JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
            } else {
                new PurchaseClass();
            }
            }
        });

        buttonClear1 = new JButton("Clear");
        buttonClear1.setBounds(10,436,290,35);
        buttonClear1.setFocusable(false);
        buttonClear1.setBackground(new Color(50,60,150));
        buttonClear1.setForeground(new Color(230,130,30));
        buttonClear1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textID.getText().toString().isEmpty() || textOwnerName.getText().toString().isEmpty() || textSize.getText().toString().isEmpty() ||textPrice.getText().toString().isEmpty() || textLocation.getText().toString().isEmpty()|| textDate.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textID.getText().toString());
                    String OwnerName = textOwnerName.getText().toString();
                    long size = Integer.parseInt(textSize.getText().toString());
                    long price = Integer.parseInt(textPrice.getText().toString());
                    String address = textLocation.getText().toString();
                    String date = textLocation.getText().toString();

                    int row = table1.getSelectedRow();
                    model1.setValueAt(id,row,0);
                    model1.setValueAt(OwnerName,row,1);
                    model1.setValueAt(size,row,2);
                    model1.setValueAt(price,row,3);
                    model1.setValueAt(address,row,4);
                    model1.setValueAt(address,row,5);


                    textID.setText("");
                    textOwnerName.setText("");
                    textSize.setText("");
                    textPrice.setText("");
                    textLocation.setText("");
                    textDate.setText("");
                    JOptionPane.showMessageDialog(null,"Cleared Successfully");

                }
            }
        });


        panel2.add(labelID1);
        panel2.add(textID);
        panel2.add(buttonAdd1);

        panel2.add(labelOwnerName1);
        panel2.add(textOwnerName);
        panel2.add(buttonUpdate1);

        panel2.add(labelSize1);
        panel2.add(textSize);
        panel2.add(buttonDelete1);

        panel2.add(labelPrice1);
        panel2.add(textPrice);
        panel2.add(buttonClear1);

        panel2.add(labelLocation1);
        panel2.add(textLocation);
        panel2.add(buttonSelect1);

        panel2.add(labelDate1);
        panel2.add(textDate);

        panel3 = new JPanel();
        panel3.setBackground(new Color(200,120,60));
        panel3.setForeground(new Color(40,90,140));
        panel3.setBounds(0,550,1000,150);

        water1 = new Checkbox("Water");
        water1.setForeground(new Color(60,70,170));
        water1.setFocusable(false);
        electricity1 = new Checkbox("Electricity");
        electricity1.setForeground(new Color(60,70,170));
        electricity1.setFocusable(false);
        gas1 = new Checkbox("Gas");
        gas1.setForeground(new Color(60,70,170));
        gas1.setFocusable(false);
        checkbutton1 = new JButton("Equipment");
        checkbutton1.setFocusable(false);
        checkbutton1.setBackground(new Color(50,60,150));
        checkbutton1.setForeground(new Color(230,130,30));
        panel3.add(water1);
        panel3.add(electricity1);
        panel3.add(gas1);
        panel3.add(checkbutton1);

        panel1.revalidate();
        panel1.setVisible(true);
        purchasePanelNew.add(panel1,BorderLayout.NORTH);
        purchasePanelNew.add(panel2,BorderLayout.CENTER);
        purchasePanelNew.add(panel3,BorderLayout.SOUTH);
//Table 2 ***************************************************************************************************************

        panel1RR = new JPanel();
        table2 = new JTable();
        column2 = new Object[]{"ID", "Owner's Name", "Size", "Price", "Location", "Date of Recent Edition"};
        model2 = new DefaultTableModel();
        panel1RR.setBackground(new Color(220,140,30));
        panel1RR.setForeground(new Color(0,200,100));
        panel1RR.setBounds(0,0,1000,400);

        model2.setColumnIdentifiers(column2);
        table2.setModel(model2);

        table2.setBackground(new Color(200,170,150));
        table2.setForeground(new Color(40,50,120));
        table2.setSelectionBackground(new Color(180,130,150));
        table2.setGridColor(new Color(220,60,70));
        table2.setSelectionForeground(new Color(10,220,10));
        table2.setFont(new Font(null,Font.BOLD,10));
        table2.setRowHeight(30);
        table2.setAutoCreateRowSorter(true);
        table2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table2.setPreferredSize(new Dimension(700,400));



        pane2 = new JScrollPane(table2);
        panel1RR.setLayout(new BorderLayout());
        pane2.setForeground(new Color(10,10,200));
        pane2.setBackground(new Color(200,10,10));
        panel1RR.add(pane2);

        panel2RR = new JPanel();
        panel2RR.setBackground(new Color(220,140,30));
        panel2RR.setForeground(new Color(0,200,100));
        panel2RR.setBounds(0,400,1000,200);
        panel2RR.setLayout(new GridLayout(6,3));

        textIDRR = new JTextField();
        textIDRR.setBackground(new Color(140,140,160));
        textIDRR.setColumns(10);
        textIDRR.setFont(new Font(null,Font.BOLD,20));

        textOwnerNameRR = new JTextField();
        textOwnerNameRR.setBackground(new Color(140,140,160));
        textOwnerNameRR.setColumns(10);
        textOwnerNameRR.setFont(new Font(null,Font.BOLD,20));

        textSizeRR = new JTextField();
        textSizeRR.setBackground(new Color(140,140,160));
        textSizeRR.setColumns(10);
        textSizeRR.setFont(new Font(null,Font.BOLD,20));

        textPriceRR = new JTextField();
        textPriceRR.setBackground(new Color(140,140,160));
        textPriceRR.setColumns(10);
        textPriceRR.setFont(new Font(null,Font.BOLD,20));

        textLocationRR = new JTextField();
        textLocationRR.setBackground(new Color(140,140,160));
        textLocationRR.setColumns(10);
        textLocationRR.setFont(new Font(null,Font.BOLD,20));

        textDateRR = new JTextField();
        textDateRR.setBackground(new Color(140,140,160));
        textDateRR.setColumns(10);
        textDateRR.setFont(new Font(null,Font.BOLD,20));

        labelID2 = new JLabel("ID");
        labelID2.setFont(new Font(null,Font.BOLD,19));
        labelID2.setForeground(new Color(40,40,40));


        labelOwnerName2 = new JLabel("Owner's Name");
        labelOwnerName2.setFont(new Font(null,Font.BOLD,19));
        labelOwnerName2.setForeground(new Color(40,40,40));


        labelSize2 = new JLabel("Size(m^2)");
        labelSize2.setFont(new Font(null,Font.BOLD,19));
        labelSize2.setForeground(new Color(40,40,40));


        labelPrice2 = new JLabel("Price(Million)");
        labelPrice2.setFont(new Font(null,Font.BOLD,19));
        labelPrice2.setForeground(new Color(40,40,40));


        labelLocation2 = new JLabel("Location");
        labelLocation2.setFont(new Font(null,Font.BOLD,19));
        labelLocation2.setForeground(new Color(40,40,40));

        labelDate2 = new JLabel("Date of Recent Edition");
        labelDate2.setFont(new Font(null,Font.BOLD,19));
        labelDate2.setForeground(new Color(40,40,40));


        row2 = new Object[5];

        table2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int rowIndex = table2.getSelectedRow();
                long id = (long)model2.getValueAt(rowIndex, 0);
                String  OwnerName = (String)model2.getValueAt(rowIndex, 1);
                long size = (long)model2.getValueAt(rowIndex, 2);
                long price = (long)model2.getValueAt(rowIndex, 3);
                String  address = (String)model2.getValueAt(rowIndex, 4);
                String Date = (String)model2.getValueAt(rowIndex, 5);

                textIDRR.setText(String.valueOf(id));
                textOwnerNameRR.setText(OwnerName);
                textSizeRR.setText(String.valueOf(size));
                textPriceRR.setText(String.valueOf(price));
                textLocationRR.setText(address);
                textDateRR.setText(Date);
            }
        });

        buttonAdd2 = new JButton("Add");
        buttonAdd2.setBounds(10,436,290,35);
        buttonAdd2.setFocusable(false);
        buttonAdd2.setBackground(new Color(50,60,150));
        buttonAdd2.setForeground(new Color(230,130,30));
        buttonAdd2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(textIDRR.getText().toString().isEmpty() || textOwnerNameRR.getText().toString().isEmpty() || textSizeRR.getText().toString().isEmpty() || textPriceRR.getText().toString().isEmpty() || textLocationRR.getText().toString().isEmpty() || textDateRR.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please fill all Fields First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDRR.getText().toString());
                    String OwnerName = textOwnerNameRR.getText().toString();
                    long size = Integer.parseInt(textSizeRR.getText().toString());
                    long price = Integer.parseInt(textPriceRR.getText().toString());
                    String address = textLocationRR.getText().toString();
                    String date = textDateRR.getText().toString();

                    Object[] newRow = {id, OwnerName, size, price, address, date};
                    model2.addRow(newRow);

                    textIDRR.setText(null);
                    textOwnerNameRR.setText(null);
                    textSizeRR.setText(null);
                    textPriceRR.setText(null);
                    textLocationRR.setText(null);
                    textDateRR.setText(null);
                    JOptionPane.showMessageDialog(null,"Added Successfully");

                }
            }
        });

        buttonDelete2 = new JButton("Delete");
        buttonDelete2.setBounds(313,436,290,35);
        buttonDelete2.setFocusable(false);
        buttonDelete2.setBackground(new Color(50,60,150));
        buttonDelete2.setForeground(new Color(230,130,30));
        buttonDelete2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(table2.getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    int selection = JOptionPane.showConfirmDialog(null, "Do you want to delete this row?", "confirm", JOptionPane.YES_NO_OPTION);

                    if(selection==JOptionPane.YES_OPTION){
                        model2.removeRow(table2.getSelectedRow());
                    }
                }
            }
        });

        buttonUpdate2 = new JButton("Update");
        buttonUpdate2.setBounds(313,436,290,35);
        buttonUpdate2.setFocusable(false);
        buttonUpdate2.setBackground(new Color(50,60,150));
        buttonUpdate2.setForeground(new Color(230,130,30));
        buttonUpdate2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDRR.getText().toString().isEmpty() || textOwnerNameRR.getText().toString().isEmpty() || textSizeRR.getText().toString().isEmpty() || textPriceRR.getText().toString().isEmpty() || textLocationRR.getText().toString().isEmpty()|| textDateRR.getText().toString().isEmpty() ) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDRR.getText().toString());
                    String OwnerName = textOwnerNameRR.getText().toString();
                    long size = Integer.parseInt(textSizeRR.getText().toString());
                    long price = Integer.parseInt(textPriceRR.getText().toString());
                    String location = textOwnerNameRR.getText().toString();
                    String date = textDateRR.getText().toString();

                    int row = table2.getSelectedRow();
                    model2.setValueAt(id,row,0);
                    model2.setValueAt(OwnerName,row,1);
                    model2.setValueAt(size,row,2);
                    model2.setValueAt(price,row,3);
                    model2.setValueAt(price,row,4);
                    model2.setValueAt(date,row,5);

                    textIDRR.setText(null);
                    textOwnerNameRR.setText(null);
                    textSizeRR.setText(null);
                    textPriceRR.setText(null);
                    textLocationRR.setText(null);
                    textDateRR.setText(null);

                    JOptionPane.showMessageDialog(null,"Updated Successfully");

                }
            }

        });
        buttonSelect2 = new JButton("Rent");
        buttonSelect2.setBounds(313,436,290,35);
        buttonSelect2.setFocusable(false);
        buttonSelect2.setBackground(new Color(50,60,150));
        buttonSelect2.setForeground(new Color(230,130,30));
        buttonSelect2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDRR.getText().toString().isEmpty() || textOwnerNameRR.getText().toString().isEmpty() || textSizeRR.getText().toString().isEmpty() ||textPriceRR.getText().toString().isEmpty() || textLocationRR.getText().toString().isEmpty()|| textDateRR.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    new RentClass();
                }
            }
        });

        buttonClear2 = new JButton("Clear");
        buttonClear2.setBounds(10,436,290,35);
        buttonClear2.setFocusable(false);
        buttonClear2.setBackground(new Color(50,60,150));
        buttonClear2.setForeground(new Color(230,130,30));
        buttonClear2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDRR.getText().toString().isEmpty() || textOwnerNameRR.getText().toString().isEmpty() || textSizeRR.getText().toString().isEmpty() ||textPriceRR.getText().toString().isEmpty() || textLocationRR.getText().toString().isEmpty()|| textDateRR.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDRR.getText().toString());
                    String OwnerName = textOwnerNameRR.getText().toString();
                    long size = Integer.parseInt(textSizeRR.getText().toString());
                    long price = Integer.parseInt(textPriceRR.getText().toString());
                    String address = textLocationRR.getText().toString();
                    String date = textLocationRR.getText().toString();

                    int row = table2.getSelectedRow();
                    model2.setValueAt(id,row,0);
                    model2.setValueAt(OwnerName,row,1);
                    model2.setValueAt(size,row,2);
                    model2.setValueAt(price,row,3);
                    model2.setValueAt(address,row,4);
                    model2.setValueAt(address,row,5);


                    textIDRR.setText("");
                    textOwnerNameRR.setText("");
                    textSizeRR.setText("");
                    textPriceRR.setText("");
                    textLocationRR.setText("");
                    textDateRR.setText("");
                    JOptionPane.showMessageDialog(null,"Cleared Successfully");

                }
            }
        });


        panel2RR.add(labelID2);
        panel2RR.add(textIDRR);
        panel2RR.add(buttonAdd2);

        panel2RR.add(labelOwnerName2);
        panel2RR.add(textOwnerNameRR);
        panel2RR.add(buttonUpdate2);

        panel2RR.add(labelSize2);
        panel2RR.add(textSizeRR);
        panel2RR.add(buttonDelete2);

        panel2RR.add(labelPrice2);
        panel2RR.add(textPriceRR);
        panel2RR.add(buttonClear2);

        panel2RR.add(labelLocation2);
        panel2RR.add(textLocationRR);
        panel2RR.add(buttonSelect2);

        panel2RR.add(labelDate2);
        panel2RR.add(textDateRR);

        panel3RR = new JPanel();
        panel3RR.setBackground(new Color(200,120,60));
        panel3RR.setForeground(new Color(0,200,100));
        panel3RR.setBounds(0,600,1000,100);

        water2 = new Checkbox("Water");
        water2.setForeground(new Color(60,70,170));
        water2.setFocusable(false);
        electricity2 = new Checkbox("Electricity");
        electricity2.setForeground(new Color(60,70,170));
        electricity2.setFocusable(false);
        gas2 = new Checkbox("Gas");
        gas2.setForeground(new Color(60,70,170));
        gas2.setFocusable(false);
        checkbutton2 = new JButton("Equipment");
        checkbutton2.setFocusable(false);
        checkbutton2.setBackground(new Color(50,60,150));
        checkbutton2.setForeground(new Color(230,130,30));
        panel3RR.add(water2);
        panel3RR.add(electricity2);
        panel3RR.add(gas2);
        panel3RR.add(checkbutton2);

        panel1RR.revalidate();
        panel1RR.setVisible(true);
        rentPanelNew.add(panel1RR,BorderLayout.NORTH);
        rentPanelNew.add(panel2RR,BorderLayout.CENTER);
        rentPanelNew.add(panel3RR,BorderLayout.SOUTH);
//Table 3 **************************************************************************************************************  

        panel1GG = new JPanel();
        table3 = new JTable();
        column3 = new Object[]{"ID", "Owner'S Name", "Size", "Price", "Location", "Date of Recent Edition"};
        model3 = new DefaultTableModel();
        panel1GG.setBackground(new Color(220,140,30));
        panel1GG.setForeground(new Color(0,200,100));
        panel1GG.setBounds(0,0,1000,400);

        model3.setColumnIdentifiers(column3);
        table3.setModel(model3);

        table3.setBackground(new Color(200,170,150));
        table3.setForeground(new Color(40,50,120));
        table3.setSelectionBackground(new Color(180,130,150));
        table3.setGridColor(new Color(220,60,70));
        table3.setSelectionForeground(new Color(10,220,10));
        table3.setFont(new Font(null,Font.BOLD,10));
        table3.setRowHeight(30);
        table3.setAutoCreateRowSorter(true);
        table3.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table3.setPreferredSize(new Dimension(700,400));



        pane3 = new JScrollPane(table3);
        panel1GG.setLayout(new BorderLayout());
        pane3.setForeground(new Color(10,10,200));
        pane3.setBackground(new Color(200,10,10));
        panel1GG.add(pane3);

        panel2GG = new JPanel();
        panel2GG.setBackground(new Color(220,140,30));
        panel2GG.setForeground(new Color(0,200,100));
        panel2GG.setBounds(0,400,1000,200);
        panel2GG.setLayout(new GridLayout(6,3));

        textIDGG = new JTextField();
        textIDGG.setBackground(new Color(140,140,160));
        textIDGG.setColumns(10);
        textIDGG.setFont(new Font(null,Font.BOLD,20));

        textOwnerNameGG = new JTextField();
        textOwnerNameGG .setBackground(new Color(140,140,160));
        textOwnerNameGG .setColumns(10);
        textOwnerNameGG .setFont(new Font(null,Font.BOLD,20));

        textSizeGG = new JTextField();
        textSizeGG.setBackground(new Color(140,140,160));
        textSizeGG.setColumns(10);
        textSizeGG.setFont(new Font(null,Font.BOLD,20));

        textPriceGG = new JTextField();
        textPriceGG.setBackground(new Color(140,140,160));
        textPriceGG.setColumns(10);
        textPriceGG.setFont(new Font(null,Font.BOLD,20));

        textLocationGG = new JTextField();
        textLocationGG.setBackground(new Color(140,140,160));
        textLocationGG.setColumns(10);
        textLocationGG.setFont(new Font(null,Font.BOLD,20));

        textDateGG = new JTextField();
        textDateGG.setBackground(new Color(140,140,160));
        textDateGG.setColumns(10);
        textDateGG.setFont(new Font(null,Font.BOLD,20));

        labelID3 = new JLabel("ID");
        labelID3.setFont(new Font(null,Font.BOLD,19));
        labelID3.setForeground(new Color(40,40,40));


        labelOwnerName3 = new JLabel("Owner's Name");
        labelOwnerName3.setFont(new Font(null,Font.BOLD,19));
        labelOwnerName3.setForeground(new Color(40,40,40));


        labelSize3 = new JLabel("Size(m^2)");
        labelSize3.setFont(new Font(null,Font.BOLD,19));
        labelSize3.setForeground(new Color(40,40,40));


        labelPrice3 = new JLabel("Price(Million)");
        labelPrice3.setFont(new Font(null,Font.BOLD,19));
        labelPrice3.setForeground(new Color(40,40,40));


        labelLocation3 = new JLabel("Location");
        labelLocation3.setFont(new Font(null,Font.BOLD,19));
        labelLocation3.setForeground(new Color(40,40,40));

        labelDate3 = new JLabel("Date of Recent Edition");
        labelDate3.setFont(new Font(null,Font.BOLD,19));
        labelDate3.setForeground(new Color(40,40,40));


        row3 = new Object[5];

        table3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int rowIndex = table3.getSelectedRow();
                long id = (long)model3.getValueAt(rowIndex, 0);
                String  OwnerName = (String)model3.getValueAt(rowIndex, 1);
                long size = (long)model3.getValueAt(rowIndex, 2);
                long price = (long)model3.getValueAt(rowIndex, 3);
                String  address = (String)model3.getValueAt(rowIndex, 4);
                String Date = (String)model3.getValueAt(rowIndex, 5);

                textIDGG.setText(String.valueOf(id));
                textOwnerNameGG .setText(OwnerName);
                textSizeGG.setText(String.valueOf(size));
                textPriceGG.setText(String.valueOf(price));
                textLocationGG.setText(address);
                textDateGG.setText(Date);
            }
        });

        buttonAdd3 = new JButton("Add");
        buttonAdd3.setBounds(10,436,290,35);
        buttonAdd3.setFocusable(false);
        buttonAdd3.setBackground(new Color(50,60,150));
        buttonAdd3.setForeground(new Color(230,130,30));
        buttonAdd3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(textIDGG.getText().toString().isEmpty() || textOwnerNameGG .getText().toString().isEmpty() || textSizeGG.getText().toString().isEmpty() || textPriceGG.getText().toString().isEmpty() || textLocationGG.getText().toString().isEmpty() || textDateGG.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please fill all Fields First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDGG.getText().toString());
                    String OwnerName = textOwnerNameGG .getText().toString();
                    long size = Integer.parseInt(textSizeGG.getText().toString());
                    long price = Integer.parseInt(textPriceGG.getText().toString());
                    String address = textLocationGG.getText().toString();
                    String date = textDateGG.getText().toString();

                    Object[] newRow = {id, OwnerName, size, price, address, date};
                    model3.addRow(newRow);

                    textIDGG.setText(null);
                    textOwnerNameGG .setText(null);
                    textSizeGG.setText(null);
                    textPriceGG.setText(null);
                    textLocationGG.setText(null);
                    textDateGG.setText(null);
                    JOptionPane.showMessageDialog(null,"Added Successfully");

                }
            }
        });

        buttonDelete3 = new JButton("Delete");
        buttonDelete3.setBounds(313,436,290,35);
        buttonDelete3.setFocusable(false);
        buttonDelete3.setBackground(new Color(50,60,150));
        buttonDelete3.setForeground(new Color(230,130,30));
        buttonDelete3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(table3.getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    int selection = JOptionPane.showConfirmDialog(null, "Do you want to delete this row?", "confirm", JOptionPane.YES_NO_OPTION);

                    if(selection==JOptionPane.YES_OPTION){
                        model3.removeRow(table3.getSelectedRow());
                    }
                }
            }
        });

        buttonUpdate3 = new JButton("Update");
        buttonUpdate3.setBounds(313,436,290,35);
        buttonUpdate3.setFocusable(false);
        buttonUpdate3.setBackground(new Color(50,60,150));
        buttonUpdate3.setForeground(new Color(230,130,30));
        buttonUpdate3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDGG.getText().toString().isEmpty() || textOwnerNameGG .getText().toString().isEmpty() || textSizeGG.getText().toString().isEmpty() || textPriceGG.getText().toString().isEmpty() || textLocationGG.getText().toString().isEmpty()|| textDateGG.getText().toString().isEmpty() ) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDGG.getText().toString());
                    String OwnerName = textOwnerNameGG .getText().toString();
                    long size = Integer.parseInt(textSizeGG.getText().toString());
                    long price = Integer.parseInt(textPriceGG.getText().toString());
                    String location = textIDGG.getText().toString();
                    String date = textDateGG.getText().toString();

                    int row = table3.getSelectedRow();
                    model3.setValueAt(id,row,0);
                    model3.setValueAt(OwnerName,row,1);
                    model3.setValueAt(size,row,2);
                    model3.setValueAt(price,row,3);
                    model3.setValueAt(price,row,4);
                    model3.setValueAt(date,row,5);

                    textIDGG.setText(null);
                    textOwnerNameGG .setText(null);
                    textSizeGG.setText(null);
                    textPriceGG.setText(null);
                    textLocationGG.setText(null);
                    textDateGG.setText(null);

                    JOptionPane.showMessageDialog(null,"Updated Successfully");

                }
            }

        });
        buttonSelect3 = new JButton("Purchase");
        buttonSelect3.setBounds(313,436,290,35);
        buttonSelect3.setFocusable(false);
        buttonSelect3.setBackground(new Color(50,60,150));
        buttonSelect3.setForeground(new Color(230,130,30));
        buttonSelect3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDGG.getText().toString().isEmpty() || textOwnerNameGG .getText().toString().isEmpty() || textSizeGG.getText().toString().isEmpty() ||textPriceGG.getText().toString().isEmpty() || textLocationGG.getText().toString().isEmpty()|| textDateGG.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    new PurchaseClassOld();
                }
            }
        });

        buttonClear3 = new JButton("Clear");
        buttonClear3.setBounds(10,436,290,35);
        buttonClear3.setFocusable(false);
        buttonClear3.setBackground(new Color(50,60,150));
        buttonClear3.setForeground(new Color(230,130,30));
        buttonClear3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDGG.getText().toString().isEmpty() || textOwnerNameGG .getText().toString().isEmpty() || textSizeGG.getText().toString().isEmpty() ||textPriceGG.getText().toString().isEmpty() || textLocationGG.getText().toString().isEmpty()|| textDateGG.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDGG.getText().toString());
                    String OwnerName = textOwnerNameGG .getText().toString();
                    long size = Integer.parseInt(textSizeGG.getText().toString());
                    long price = Integer.parseInt(textPriceGG.getText().toString());
                    String address = textLocationGG.getText().toString();
                    String date = textLocationGG.getText().toString();

                    int row = table3.getSelectedRow();
                    model3.setValueAt(id,row,0);
                    model3.setValueAt(OwnerName,row,1);
                    model3.setValueAt(size,row,2);
                    model3.setValueAt(price,row,3);
                    model3.setValueAt(address,row,4);
                    model3.setValueAt(address,row,5);


                    textIDGG.setText("");
                    textOwnerNameGG .setText("");
                    textSizeGG.setText("");
                    textPriceGG.setText("");
                    textLocationGG.setText("");
                    textDateGG.setText("");
                    JOptionPane.showMessageDialog(null,"Cleared Successfully");

                }
            }
        });


        panel2GG.add(labelID3);
        panel2GG.add(textIDGG);
        panel2GG.add(buttonAdd3);

        panel2GG.add(labelOwnerName3);
        panel2GG.add(textOwnerNameGG );
        panel2GG.add(buttonUpdate3);

        panel2GG.add(labelSize3);
        panel2GG.add(textSizeGG);
        panel2GG.add(buttonDelete3);

        panel2GG.add(labelPrice3);
        panel2GG.add(textPriceGG);
        panel2GG.add(buttonClear3);

        panel2GG.add(labelLocation3);
        panel2GG.add(textLocationGG);
        panel2GG.add(buttonSelect3);

        panel2GG.add(labelDate3);
        panel2GG.add(textDateGG);

        panel3GG = new JPanel();
        panel3GG.setBackground(new Color(200,120,60));
        panel3GG.setForeground(new Color(0,200,100));
        panel3GG.setBounds(0,600,1000,100);

        water3 = new Checkbox("Water");
        water3.setForeground(new Color(60,70,170));
        water3.setFocusable(false);
        electricity3 = new Checkbox("Electricity");
        electricity3.setForeground(new Color(60,70,170));
        electricity3.setFocusable(false);
        gas3 = new Checkbox("Gas");
        gas3.setForeground(new Color(60,70,170));
        gas3.setFocusable(false);
        checkbutton3 = new JButton("Equipment");
        checkbutton3.setFocusable(false);
        checkbutton3.setBackground(new Color(50,60,150));
        checkbutton3.setForeground(new Color(230,130,30));
        panel3GG.add(water3);
        panel3GG.add(electricity3);
        panel3GG.add(gas3);
        panel3GG.add(checkbutton3);

        panel1GG.revalidate();
        panel1GG.setVisible(true);
        purchasePanelOld.add(panel1GG,BorderLayout.NORTH);
        purchasePanelOld.add(panel2GG,BorderLayout.CENTER);
        purchasePanelOld.add(panel3GG,BorderLayout.SOUTH);
//Table 4***************************************************************************************************************        

        panel1HH = new JPanel();
        table4 = new JTable();
        column4 = new Object[]{"ID", "Owner's Name", "Size", "Price", "Location", "Date of Recent Edition"};
        model4 = new DefaultTableModel();
        panel1HH.setBackground(new Color(220,140,30));
        panel1HH.setForeground(new Color(0,200,100));
        panel1HH.setBounds(0,0,1000,400);

        model4.setColumnIdentifiers(column4);
        table4.setModel(model4);

        table4.setBackground(new Color(200,170,150));
        table4.setForeground(new Color(40,50,120));
        table4.setSelectionBackground(new Color(180,130,150));
        table4.setGridColor(new Color(220,60,70));
        table4.setSelectionForeground(new Color(10,220,10));
        table4.setFont(new Font(null,Font.BOLD,10));
        table4.setRowHeight(30);
        table4.setAutoCreateRowSorter(true);
        table4.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table4.setPreferredSize(new Dimension(700,400));



        pane4 = new JScrollPane(table4);
        panel1HH.setLayout(new BorderLayout());
        pane4.setForeground(new Color(10,10,200));
        pane4.setBackground(new Color(200,10,10));
        panel1HH.add(pane4);

        panel2HH = new JPanel();
        panel2HH.setBackground(new Color(220,140,30));
        panel2HH.setForeground(new Color(0,200,100));
        panel2HH.setBounds(0,400,1000,200);
        panel2HH.setLayout(new GridLayout(6,3));

        textIDHH = new JTextField();
        textIDHH.setBackground(new Color(140,140,160));
        textIDHH.setColumns(10);
        textIDHH.setFont(new Font(null,Font.BOLD,20));

        textOwnerNameHH = new JTextField();
        textOwnerNameHH .setBackground(new Color(140,140,160));
        textOwnerNameHH .setColumns(10);
        textOwnerNameHH .setFont(new Font(null,Font.BOLD,20));

        textSizeHH = new JTextField();
        textSizeHH.setBackground(new Color(140,140,160));
        textSizeHH.setColumns(10);
        textSizeHH.setFont(new Font(null,Font.BOLD,20));

        textPriceHH = new JTextField();
        textPriceHH.setBackground(new Color(140,140,160));
        textPriceHH.setColumns(10);
        textPriceHH.setFont(new Font(null,Font.BOLD,20));

        textLocationHH = new JTextField();
        textLocationHH.setBackground(new Color(140,140,160));
        textLocationHH.setColumns(10);
        textLocationHH.setFont(new Font(null,Font.BOLD,20));

        textDateHH = new JTextField();
        textDateHH.setBackground(new Color(140,140,160));
        textDateHH.setColumns(10);
        textDateHH.setFont(new Font(null,Font.BOLD,20));

        labelID4 = new JLabel("ID");
        labelID4.setFont(new Font(null,Font.BOLD,19));
        labelID4.setForeground(new Color(40,40,40));


        labelOwnerName4 = new JLabel("Owner's Name");
        labelOwnerName4.setFont(new Font(null,Font.BOLD,19));
        labelOwnerName4.setForeground(new Color(40,40,40));


        labelSize4 = new JLabel("Size(m^2)");
        labelSize4.setFont(new Font(null,Font.BOLD,19));
        labelSize4.setForeground(new Color(40,40,40));


        labelPrice4 = new JLabel("Price(Million)");
        labelPrice4.setFont(new Font(null,Font.BOLD,19));
        labelPrice4.setForeground(new Color(40,40,40));


        labelLocation4 = new JLabel("Location");
        labelLocation4.setFont(new Font(null,Font.BOLD,19));
        labelLocation4.setForeground(new Color(40,40,40));

        labelDate4 = new JLabel("Date of Recent Edition");
        labelDate4.setFont(new Font(null,Font.BOLD,19));
        labelDate4.setForeground(new Color(40,40,40));


        row4 = new Object[5];

        table4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int rowIndex = table4.getSelectedRow();
                long id = (long)model4.getValueAt(rowIndex, 0);
                String  OwnerName = (String)model4.getValueAt(rowIndex, 1);
                long size = (long)model4.getValueAt(rowIndex, 2);
                long price = (long)model4.getValueAt(rowIndex, 3);
                String  address = (String)model4.getValueAt(rowIndex, 4);
                String Date = (String)model4.getValueAt(rowIndex, 5);

                textIDHH.setText(String.valueOf(id));
                textOwnerNameHH .setText(OwnerName);
                textSizeHH.setText(String.valueOf(size));
                textPriceHH.setText(String.valueOf(price));
                textLocationHH.setText(address);
                textDateHH.setText(Date);
            }
        });

        buttonAdd4 = new JButton("Add");
        buttonAdd4.setBounds(10,436,290,35);
        buttonAdd4.setFocusable(false);
        buttonAdd4.setBackground(new Color(50,60,150));
        buttonAdd4.setForeground(new Color(230,130,30));
        buttonAdd4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(textIDHH.getText().toString().isEmpty() || textOwnerNameHH .getText().toString().isEmpty() || textSizeHH.getText().toString().isEmpty() || textPriceHH.getText().toString().isEmpty() || textLocationHH.getText().toString().isEmpty() || textDateHH.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please fill all Fields First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDHH.getText().toString());
                    String OwnerName = textOwnerNameHH .getText().toString();
                    long size = Integer.parseInt(textSizeHH.getText().toString());
                    long price = Integer.parseInt(textPriceHH.getText().toString());
                    String address = textLocationHH.getText().toString();
                    String date = textDateHH.getText().toString();

                    Object[] newRow = {id, OwnerName, size, price, address, date};
                    model4.addRow(newRow);

                    textIDHH.setText(null);
                    textOwnerNameHH .setText(null);
                    textSizeHH.setText(null);
                    textPriceHH.setText(null);
                    textLocationHH.setText(null);
                    textDateHH.setText(null);
                    JOptionPane.showMessageDialog(null,"Added Successfully");

                }
            }
        });

        buttonDelete4 = new JButton("Delete");
        buttonDelete4.setBounds(313,436,290,35);
        buttonDelete4.setFocusable(false);
        buttonDelete4.setBackground(new Color(50,60,150));
        buttonDelete4.setForeground(new Color(230,130,30));
        buttonDelete4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(table4.getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    int selection = JOptionPane.showConfirmDialog(null, "Do you want to delete this row?", "confirm", JOptionPane.YES_NO_OPTION);

                    if(selection==JOptionPane.YES_OPTION){
                        model4.removeRow(table4.getSelectedRow());
                    }
                }
            }
        });

        buttonUpdate4 = new JButton("Update");
        buttonUpdate4.setBounds(313,436,290,35);
        buttonUpdate4.setFocusable(false);
        buttonUpdate4.setBackground(new Color(50,60,150));
        buttonUpdate4.setForeground(new Color(230,130,30));
        buttonUpdate4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDHH.getText().toString().isEmpty() || textOwnerNameHH .getText().toString().isEmpty() || textSizeHH.getText().toString().isEmpty() || textPriceHH.getText().toString().isEmpty() || textLocationHH.getText().toString().isEmpty()|| textDateHH.getText().toString().isEmpty() ) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDHH.getText().toString());
                    String OwnerName = textOwnerNameHH .getText().toString();
                    long size = Integer.parseInt(textSizeHH.getText().toString());
                    long price = Integer.parseInt(textPriceHH.getText().toString());
                    String location = textIDHH.getText().toString();
                    String date = textDateHH.getText().toString();

                    int row = table4.getSelectedRow();
                    model4.setValueAt(id,row,0);
                    model4.setValueAt(OwnerName,row,1);
                    model4.setValueAt(size,row,2);
                    model4.setValueAt(price,row,3);
                    model4.setValueAt(price,row,4);
                    model4.setValueAt(date,row,5);

                    textIDHH.setText(null);
                    textOwnerNameHH .setText(null);
                    textSizeHH.setText(null);
                    textPriceHH.setText(null);
                    textLocationHH.setText(null);
                    textDateHH.setText(null);

                    JOptionPane.showMessageDialog(null,"Updated Successfully");

                }
            }

        });
        buttonSelect4 = new JButton("Rent");
        buttonSelect4.setBounds(313,436,290,35);
        buttonSelect4.setFocusable(false);
        buttonSelect4.setBackground(new Color(50,60,150));
        buttonSelect4.setForeground(new Color(230,130,30));
        buttonSelect4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDHH.getText().toString().isEmpty() || textOwnerNameHH .getText().toString().isEmpty() || textSizeHH.getText().toString().isEmpty() ||textPriceHH.getText().toString().isEmpty() || textLocationHH.getText().toString().isEmpty()|| textDateHH.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    new RentClassOld();
                }
            }
        });

        buttonClear4 = new JButton("Clear");
        buttonClear4.setBounds(10,436,290,35);
        buttonClear4.setFocusable(false);
        buttonClear4.setBackground(new Color(50,60,150));
        buttonClear4.setForeground(new Color(230,130,30));
        buttonClear4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDHH.getText().toString().isEmpty() || textOwnerNameHH .getText().toString().isEmpty() || textSizeHH.getText().toString().isEmpty() ||textPriceHH.getText().toString().isEmpty() || textLocationHH.getText().toString().isEmpty()|| textDateHH.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDHH.getText().toString());
                    String OwnerName = textOwnerNameHH .getText().toString();
                    long size = Integer.parseInt(textSizeHH.getText().toString());
                    long price = Integer.parseInt(textPriceHH.getText().toString());
                    String address = textLocationHH.getText().toString();
                    String date = textLocationHH.getText().toString();

                    int row = table4.getSelectedRow();
                    model4.setValueAt(id,row,0);
                    model4.setValueAt(OwnerName,row,1);
                    model4.setValueAt(size,row,2);
                    model4.setValueAt(price,row,3);
                    model4.setValueAt(address,row,4);
                    model4.setValueAt(address,row,5);


                    textIDHH.setText("");
                    textOwnerNameHH .setText("");
                    textSizeHH.setText("");
                    textPriceHH.setText("");
                    textLocationHH.setText("");
                    textDateHH.setText("");
                    JOptionPane.showMessageDialog(null,"Cleared Successfully");

                }
            }
        });


        panel2HH.add(labelID4);
        panel2HH.add(textIDHH);
        panel2HH.add(buttonAdd4);

        panel2HH.add(labelOwnerName4);
        panel2HH.add(textOwnerNameHH );
        panel2HH.add(buttonUpdate4);

        panel2HH.add(labelSize4);
        panel2HH.add(textSizeHH);
        panel2HH.add(buttonDelete4);

        panel2HH.add(labelPrice4);
        panel2HH.add(textPriceHH);
        panel2HH.add(buttonClear4);

        panel2HH.add(labelLocation4);
        panel2HH.add(textLocationHH);
        panel2HH.add(buttonSelect4);

        panel2HH.add(labelDate4);
        panel2HH.add(textDateHH);

        panel3HH = new JPanel();
        panel3HH.setBackground(new Color(200,120,60));
        panel3HH.setForeground(new Color(0,200,100));
        panel3HH.setBounds(0,600,1000,100);

        water4 = new Checkbox("Water");
        water4.setForeground(new Color(60,70,170));
        water4.setFocusable(false);
        electricity4 = new Checkbox("Electricity");
        electricity4.setForeground(new Color(60,70,170));
        electricity4.setFocusable(false);
        gas4 = new Checkbox("Gas");
        gas4.setForeground(new Color(60,70,170));
        gas4.setFocusable(false);
        checkbutton4 = new JButton("Equipment");
        checkbutton4.setFocusable(false);
        checkbutton4.setBackground(new Color(50,60,150));
        checkbutton4.setForeground(new Color(230,130,30));
        panel3HH.add(water4);
        panel3HH.add(electricity4);
        panel3HH.add(gas4);
        panel3HH.add(checkbutton4);

        panel1HH.revalidate();
        panel1HH.setVisible(true);
        rentPanelOld.add(panel1HH,BorderLayout.NORTH);
        rentPanelOld.add(panel2HH,BorderLayout.CENTER);
        rentPanelOld.add(panel3HH,BorderLayout.SOUTH);
//Table 5***************************************************************************************************************        

        panel1VV = new JPanel();
        table5 = new JTable();
        column5 = new Object[]{"ID", "Owner's Name", "Size", "Price", "Location", "Date of Recent Edition"};
        model5 = new DefaultTableModel();
        panel1VV.setBackground(new Color(220,140,30));
        panel1VV.setForeground(new Color(0,200,100));
        panel1VV.setBounds(0,0,1000,400);

        model5.setColumnIdentifiers(column5);
        table5.setModel(model5);

        table5.setBackground(new Color(200,170,150));
        table5.setForeground(new Color(40,50,120));
        table5.setSelectionBackground(new Color(180,130,150));
        table5.setGridColor(new Color(220,60,70));
        table5.setSelectionForeground(new Color(10,220,10));
        table5.setFont(new Font(null,Font.BOLD,10));
        table5.setRowHeight(30);
        table5.setAutoCreateRowSorter(true);
        table5.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table5.setPreferredSize(new Dimension(700,400));



        pane5 = new JScrollPane(table5);
        panel1VV.setLayout(new BorderLayout());
        pane5.setForeground(new Color(10,10,200));
        pane5.setBackground(new Color(200,10,10));
        panel1VV.add(pane5);

        panel2VV = new JPanel();
        panel2VV.setBackground(new Color(220,140,30));
        panel2VV.setForeground(new Color(0,200,100));
        panel2VV.setBounds(0,400,1000,200);
        panel2VV.setLayout(new GridLayout(6,3));

        textIDVV = new JTextField();
        textIDVV.setBackground(new Color(140,140,160));
        textIDVV.setColumns(10);
        textIDVV.setFont(new Font(null,Font.BOLD,20));

        textOwnerNameVV = new JTextField();
        textOwnerNameVV .setBackground(new Color(140,140,160));
        textOwnerNameVV .setColumns(10);
        textOwnerNameVV .setFont(new Font(null,Font.BOLD,20));

        textSizeVV = new JTextField();
        textSizeVV.setBackground(new Color(140,140,160));
        textSizeVV.setColumns(10);
        textSizeVV.setFont(new Font(null,Font.BOLD,20));

        textPriceVV = new JTextField();
        textPriceVV.setBackground(new Color(140,140,160));
        textPriceVV.setColumns(10);
        textPriceVV.setFont(new Font(null,Font.BOLD,20));

        textLocationVV = new JTextField();
        textLocationVV.setBackground(new Color(140,140,160));
        textLocationVV.setColumns(10);
        textLocationVV.setFont(new Font(null,Font.BOLD,20));

        textDateVV = new JTextField();
        textDateVV.setBackground(new Color(140,140,160));
        textDateVV.setColumns(10);
        textDateVV.setFont(new Font(null,Font.BOLD,20));

        labelID5 = new JLabel("ID");
        labelID5.setFont(new Font(null,Font.BOLD,19));
        labelID5.setForeground(new Color(40,40,40));


        labelOwnerName5 = new JLabel("Owner's Name");
        labelOwnerName5.setFont(new Font(null,Font.BOLD,19));
        labelOwnerName5.setForeground(new Color(40,40,40));


        labelSize5 = new JLabel("Size(ha)");
        labelSize5.setFont(new Font(null,Font.BOLD,19));
        labelSize5.setForeground(new Color(40,40,40));


        labelPrice5 = new JLabel("Price(Million)");
        labelPrice5.setFont(new Font(null,Font.BOLD,19));
        labelPrice5.setForeground(new Color(40,40,40));


        labelLocation5 = new JLabel("Location");
        labelLocation5.setFont(new Font(null,Font.BOLD,19));
        labelLocation5.setForeground(new Color(40,40,40));

        labelDate5 = new JLabel("Date of Recent Edition");
        labelDate5.setFont(new Font(null,Font.BOLD,19));
        labelDate5.setForeground(new Color(40,40,40));


        row5 = new Object[5];

        table5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int rowIndex = table5.getSelectedRow();
                long id = (long)model5.getValueAt(rowIndex, 0);
                String  OwnerName = (String)model5.getValueAt(rowIndex, 1);
                long size = (long)model5.getValueAt(rowIndex, 2);
                long price = (long)model5.getValueAt(rowIndex, 3);
                String  address = (String)model5.getValueAt(rowIndex, 4);
                String Date = (String)model5.getValueAt(rowIndex, 5);

                textIDVV.setText(String.valueOf(id));
                textOwnerNameVV .setText(OwnerName);
                textSizeVV.setText(String.valueOf(size));
                textPriceVV.setText(String.valueOf(price));
                textLocationVV.setText(address);
                textDateVV.setText(Date);
            }
        });

        buttonAdd5 = new JButton("Add");
        buttonAdd5.setBounds(10,436,290,35);
        buttonAdd5.setFocusable(false);
        buttonAdd5.setBackground(new Color(50,60,150));
        buttonAdd5.setForeground(new Color(230,130,30));
        buttonAdd5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(textIDVV.getText().toString().isEmpty() || textOwnerNameVV .getText().toString().isEmpty() || textSizeVV.getText().toString().isEmpty() || textPriceVV.getText().toString().isEmpty() || textLocationVV.getText().toString().isEmpty() || textDateVV.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please fill all Fields First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDVV.getText().toString());
                    String OwnerName = textOwnerNameVV .getText().toString();
                    long size = Integer.parseInt(textSizeVV.getText().toString());
                    long price = Integer.parseInt(textPriceVV.getText().toString());
                    String address = textLocationVV.getText().toString();
                    String date = textDateVV.getText().toString();

                    Object[] newRow = {id, OwnerName, size, price, address, date};
                    model5.addRow(newRow);

                    textIDVV.setText(null);
                    textOwnerNameVV .setText(null);
                    textSizeVV.setText(null);
                    textPriceVV.setText(null);
                    textLocationVV.setText(null);
                    textDateVV.setText(null);
                    JOptionPane.showMessageDialog(null,"Added Successfully");

                }
            }
        });

        buttonDelete5 = new JButton("Delete");
        buttonDelete5.setBounds(313,436,290,35);
        buttonDelete5.setFocusable(false);
        buttonDelete5.setBackground(new Color(50,60,150));
        buttonDelete5.setForeground(new Color(230,130,30));
        buttonDelete5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(table5.getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    int selection = JOptionPane.showConfirmDialog(null, "Do you want to delete this row?", "confirm", JOptionPane.YES_NO_OPTION);

                    if(selection==JOptionPane.YES_OPTION){
                        model5.removeRow(table5.getSelectedRow());
                    }
                }
            }
        });

        buttonUpdate5 = new JButton("Update");
        buttonUpdate5.setBounds(313,436,290,35);
        buttonUpdate5.setFocusable(false);
        buttonUpdate5.setBackground(new Color(50,60,150));
        buttonUpdate5.setForeground(new Color(230,130,30));
        buttonUpdate5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDVV.getText().toString().isEmpty() || textOwnerNameVV .getText().toString().isEmpty() || textSizeVV.getText().toString().isEmpty() || textPriceVV.getText().toString().isEmpty() || textLocationVV.getText().toString().isEmpty()|| textDateVV.getText().toString().isEmpty() ) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDVV.getText().toString());
                    String OwnerName = textOwnerNameVV .getText().toString();
                    long size = Integer.parseInt(textSizeVV.getText().toString());
                    long price = Integer.parseInt(textPriceVV.getText().toString());
                    String location = textIDVV.getText().toString();
                    String date = textDateVV.getText().toString();

                    int row = table5.getSelectedRow();
                    model5.setValueAt(id,row,0);
                    model5.setValueAt(OwnerName,row,1);
                    model5.setValueAt(size,row,2);
                    model5.setValueAt(price,row,3);
                    model5.setValueAt(price,row,4);
                    model5.setValueAt(date,row,5);

                    textIDVV.setText(null);
                    textOwnerNameVV .setText(null);
                    textSizeVV.setText(null);
                    textPriceVV.setText(null);
                    textLocationVV.setText(null);
                    textDateVV.setText(null);

                    JOptionPane.showMessageDialog(null,"Updated Successfully");

                }
            }

        });
        buttonSelect5 = new JButton("Rent");
        buttonSelect5.setBounds(313,436,290,35);
        buttonSelect5.setFocusable(false);
        buttonSelect5.setBackground(new Color(50,60,150));
        buttonSelect5.setForeground(new Color(230,130,30));
        buttonSelect5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDVV.getText().toString().isEmpty() || textOwnerNameVV .getText().toString().isEmpty() || textSizeVV.getText().toString().isEmpty() ||textPriceVV.getText().toString().isEmpty() || textLocationVV.getText().toString().isEmpty()|| textDateVV.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    new PurchaseField();
                }
            }
        });

        buttonClear5 = new JButton("Clear");
        buttonClear5.setBounds(10,436,290,35);
        buttonClear5.setFocusable(false);
        buttonClear5.setBackground(new Color(50,60,150));
        buttonClear5.setForeground(new Color(230,130,30));
        buttonClear5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDVV.getText().toString().isEmpty() || textOwnerNameVV .getText().toString().isEmpty() || textSizeVV.getText().toString().isEmpty() ||textPriceVV.getText().toString().isEmpty() || textLocationVV.getText().toString().isEmpty()|| textDateVV.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDVV.getText().toString());
                    String OwnerName = textOwnerNameVV .getText().toString();
                    long size = Integer.parseInt(textSizeVV.getText().toString());
                    long price = Integer.parseInt(textPriceVV.getText().toString());
                    String address = textLocationVV.getText().toString();
                    String date = textLocationVV.getText().toString();

                    int row = table5.getSelectedRow();
                    model5.setValueAt(id,row,0);
                    model5.setValueAt(OwnerName,row,1);
                    model5.setValueAt(size,row,2);
                    model5.setValueAt(price,row,3);
                    model5.setValueAt(address,row,4);
                    model5.setValueAt(address,row,5);


                    textIDVV.setText("");
                    textOwnerNameVV .setText("");
                    textSizeVV.setText("");
                    textPriceVV.setText("");
                    textLocationVV.setText("");
                    textDateVV.setText("");
                    JOptionPane.showMessageDialog(null,"Cleared Successfully");

                }
            }
        });


        panel2VV.add(labelID5);
        panel2VV.add(textIDVV);
        panel2VV.add(buttonAdd5);

        panel2VV.add(labelOwnerName5);
        panel2VV.add(textOwnerNameVV );
        panel2VV.add(buttonUpdate5);

        panel2VV.add(labelSize5);
        panel2VV.add(textSizeVV);
        panel2VV.add(buttonDelete5);

        panel2VV.add(labelPrice5);
        panel2VV.add(textPriceVV);
        panel2VV.add(buttonClear5);

        panel2VV.add(labelLocation5);
        panel2VV.add(textLocationVV);
        panel2VV.add(buttonSelect5);

        panel2VV.add(labelDate5);
        panel2VV.add(textDateVV);

        panel3VV = new JPanel();
        panel3VV.setBackground(new Color(200,120,60));
        panel3VV.setForeground(new Color(0,200,100));
        panel3VV.setBounds(0,600,1000,100);

        panel1VV.revalidate();
        panel1VV.setVisible(true);
        purchasePanelField.add(panel1VV,BorderLayout.NORTH);
        purchasePanelField.add(panel2VV,BorderLayout.CENTER);
        purchasePanelField.add(panel3VV,BorderLayout.SOUTH);
//Table 6***************************************************************************************************************        

        panel1KK = new JPanel();
        table6 = new JTable();
        column6 = new Object[]{"ID", "Owner's Name", "Size", "Price", "Location", "Date of Recent Edition"};
        model6 = new DefaultTableModel();
        panel1KK.setBackground(new Color(220,140,30));
        panel1KK.setForeground(new Color(0,200,100));
        panel1KK.setBounds(0,0,1000,400);

        model6.setColumnIdentifiers(column6);
        table6.setModel(model6);

        table6.setBackground(new Color(200,170,150));
        table6.setForeground(new Color(40,50,120));
        table6.setSelectionBackground(new Color(180,130,150));
        table6.setGridColor(new Color(220,60,70));
        table6.setSelectionForeground(new Color(10,220,10));
        table6.setFont(new Font(null,Font.BOLD,10));
        table6.setRowHeight(30);
        table6.setAutoCreateRowSorter(true);
        table6.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table6.setPreferredSize(new Dimension(700,400));



        pane6 = new JScrollPane(table6);
        panel1KK.setLayout(new BorderLayout());
        pane6.setForeground(new Color(10,10,200));
        pane6.setBackground(new Color(200,10,10));
        panel1KK.add(pane6);

        panel2KK = new JPanel();
        panel2KK.setBackground(new Color(220,140,30));
        panel2KK.setForeground(new Color(0,200,100));
        panel2KK.setBounds(0,400,1000,200);
        panel2KK.setLayout(new GridLayout(6,3));

        textIDKK = new JTextField();
        textIDKK.setBackground(new Color(140,140,160));
        textIDKK.setColumns(10);
        textIDKK.setFont(new Font(null,Font.BOLD,20));

        textOwnerNameKK = new JTextField();
        textOwnerNameKK .setBackground(new Color(140,140,160));
        textOwnerNameKK .setColumns(10);
        textOwnerNameKK .setFont(new Font(null,Font.BOLD,20));

        textSizeKK = new JTextField();
        textSizeKK.setBackground(new Color(140,140,160));
        textSizeKK.setColumns(10);
        textSizeKK.setFont(new Font(null,Font.BOLD,20));

        textPriceKK = new JTextField();
        textPriceKK.setBackground(new Color(140,140,160));
        textPriceKK.setColumns(10);
        textPriceKK.setFont(new Font(null,Font.BOLD,20));

        textLocationKK = new JTextField();
        textLocationKK.setBackground(new Color(140,140,160));
        textLocationKK.setColumns(10);
        textLocationKK.setFont(new Font(null,Font.BOLD,20));

        textDateKK = new JTextField();
        textDateKK.setBackground(new Color(140,140,160));
        textDateKK.setColumns(10);
        textDateKK.setFont(new Font(null,Font.BOLD,20));

        labelID6 = new JLabel("ID");
        labelID6.setFont(new Font(null,Font.BOLD,19));
        labelID6.setForeground(new Color(40,40,40));


        labelOwnerName6 = new JLabel("Owner's Name");
        labelOwnerName6.setFont(new Font(null,Font.BOLD,19));
        labelOwnerName6.setForeground(new Color(40,40,40));


        labelSize6 = new JLabel("Size(ha)");
        labelSize6.setFont(new Font(null,Font.BOLD,19));
        labelSize6.setForeground(new Color(40,40,40));


        labelPrice6 = new JLabel("Price(Million)");
        labelPrice6.setFont(new Font(null,Font.BOLD,19));
        labelPrice6.setForeground(new Color(40,40,40));


        labelLocation6 = new JLabel("Location");
        labelLocation6.setFont(new Font(null,Font.BOLD,19));
        labelLocation6.setForeground(new Color(40,40,40));

        labelDate6 = new JLabel("Date of Recent Edition");
        labelDate6.setFont(new Font(null,Font.BOLD,19));
        labelDate6.setForeground(new Color(40,40,40));


        row6 = new Object[5];

        table6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int rowIndex = table6.getSelectedRow();
                long id = (long)model6.getValueAt(rowIndex, 0);
                String  OwnerName = (String)model6.getValueAt(rowIndex, 1);
                long size = (long)model6.getValueAt(rowIndex, 2);
                long price = (long)model6.getValueAt(rowIndex, 3);
                String  address = (String)model6.getValueAt(rowIndex, 4);
                String Date = (String)model6.getValueAt(rowIndex, 5);

                textIDKK.setText(String.valueOf(id));
                textOwnerNameKK .setText(OwnerName);
                textSizeKK.setText(String.valueOf(size));
                textPriceKK.setText(String.valueOf(price));
                textLocationKK.setText(address);
                textDateKK.setText(Date);
            }
        });

        buttonAdd6 = new JButton("Add");
        buttonAdd6.setBounds(10,436,290,35);
        buttonAdd6.setFocusable(false);
        buttonAdd6.setBackground(new Color(50,60,150));
        buttonAdd6.setForeground(new Color(230,130,30));
        buttonAdd6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(textIDKK.getText().toString().isEmpty() || textOwnerNameKK .getText().toString().isEmpty() || textSizeKK.getText().toString().isEmpty() || textPriceKK.getText().toString().isEmpty() || textLocationKK.getText().toString().isEmpty() || textDateKK.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please fill all Fields First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDKK.getText().toString());
                    String OwnerName = textOwnerNameKK .getText().toString();
                    long size = Integer.parseInt(textSizeKK.getText().toString());
                    long price = Integer.parseInt(textPriceKK.getText().toString());
                    String address = textLocationKK.getText().toString();
                    String date = textDateKK.getText().toString();

                    Object[] newRow = {id, OwnerName, size, price, address, date};
                    model6.addRow(newRow);

                    textIDKK.setText(null);
                    textOwnerNameKK .setText(null);
                    textSizeKK.setText(null);
                    textPriceKK.setText(null);
                    textLocationKK.setText(null);
                    textDateKK.setText(null);
                    JOptionPane.showMessageDialog(null,"Added Successfully");

                }
            }
        });

        buttonDelete6 = new JButton("Delete");
        buttonDelete6.setBounds(313,436,290,35);
        buttonDelete6.setFocusable(false);
        buttonDelete6.setBackground(new Color(50,60,150));
        buttonDelete6.setForeground(new Color(230,130,30));
        buttonDelete6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(table6.getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    int selection = JOptionPane.showConfirmDialog(null, "Do you want to delete this row?", "confirm", JOptionPane.YES_NO_OPTION);

                    if(selection==JOptionPane.YES_OPTION){
                        model6.removeRow(table6.getSelectedRow());
                    }
                }
            }
        });

        buttonUpdate6 = new JButton("Update");
        buttonUpdate6.setBounds(313,436,290,35);
        buttonUpdate6.setFocusable(false);
        buttonUpdate6.setBackground(new Color(50,60,150));
        buttonUpdate6.setForeground(new Color(230,130,30));
        buttonUpdate6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDKK.getText().toString().isEmpty() || textOwnerNameKK .getText().toString().isEmpty() || textSizeKK.getText().toString().isEmpty() || textPriceKK.getText().toString().isEmpty() || textLocationKK.getText().toString().isEmpty()|| textDateKK.getText().toString().isEmpty() ) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDKK.getText().toString());
                    String OwnerName = textOwnerNameKK .getText().toString();
                    long size = Integer.parseInt(textSizeKK.getText().toString());
                    long price = Integer.parseInt(textPriceKK.getText().toString());
                    String location = textIDKK.getText().toString();
                    String date = textDateKK.getText().toString();

                    int row = table6.getSelectedRow();
                    model6.setValueAt(id,row,0);
                    model6.setValueAt(OwnerName,row,1);
                    model6.setValueAt(size,row,2);
                    model6.setValueAt(price,row,3);
                    model6.setValueAt(price,row,4);
                    model6.setValueAt(date,row,5);

                    textIDKK.setText(null);
                    textOwnerNameKK .setText(null);
                    textSizeKK.setText(null);
                    textPriceKK.setText(null);
                    textLocationKK.setText(null);
                    textDateKK.setText(null);

                    JOptionPane.showMessageDialog(null,"Updated Successfully");

                }
            }

        });
        buttonSelect6 = new JButton("Rent");
        buttonSelect6.setBounds(313,436,290,35);
        buttonSelect6.setFocusable(false);
        buttonSelect6.setBackground(new Color(50,60,150));
        buttonSelect6.setForeground(new Color(230,130,30));
        buttonSelect6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDKK.getText().toString().isEmpty() || textOwnerNameKK .getText().toString().isEmpty() || textSizeKK.getText().toString().isEmpty() ||textPriceKK.getText().toString().isEmpty() || textLocationKK.getText().toString().isEmpty()|| textDateKK.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {
                    new RentClassField();
                }
            }
        });

        buttonClear6 = new JButton("Clear");
        buttonClear6.setBounds(10,436,290,35);
        buttonClear6.setFocusable(false);
        buttonClear6.setBackground(new Color(50,60,150));
        buttonClear6.setForeground(new Color(230,130,30));
        buttonClear6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textIDKK.getText().toString().isEmpty() || textOwnerNameKK .getText().toString().isEmpty() || textSizeKK.getText().toString().isEmpty() ||textPriceKK.getText().toString().isEmpty() || textLocationKK.getText().toString().isEmpty()|| textDateKK.getText().toString().isEmpty()) {

                    JOptionPane.showMessageDialog(null,"Please Select a row First","Error",JOptionPane.ERROR_MESSAGE);
                } else {

                    long id = Integer.parseInt(textIDKK.getText().toString());
                    String OwnerName = textOwnerNameKK .getText().toString();
                    long size = Integer.parseInt(textSizeKK.getText().toString());
                    long price = Integer.parseInt(textPriceKK.getText().toString());
                    String address = textLocationKK.getText().toString();
                    String date = textLocationKK.getText().toString();

                    int row = table6.getSelectedRow();
                    model6.setValueAt(id,row,0);
                    model6.setValueAt(OwnerName,row,1);
                    model6.setValueAt(size,row,2);
                    model6.setValueAt(price,row,3);
                    model6.setValueAt(address,row,4);
                    model6.setValueAt(address,row,5);


                    textIDKK.setText("");
                    textOwnerNameKK .setText("");
                    textSizeKK.setText("");
                    textPriceKK.setText("");
                    textLocationKK.setText("");
                    textDateKK.setText("");
                    JOptionPane.showMessageDialog(null,"Cleared Successfully");

                }
            }
        });


        panel2KK.add(labelID6);
        panel2KK.add(textIDKK);
        panel2KK.add(buttonAdd6);

        panel2KK.add(labelOwnerName6);
        panel2KK.add(textOwnerNameKK );
        panel2KK.add(buttonUpdate6);

        panel2KK.add(labelSize6);
        panel2KK.add(textSizeKK);
        panel2KK.add(buttonDelete6);

        panel2KK.add(labelPrice6);
        panel2KK.add(textPriceKK);
        panel2KK.add(buttonClear6);

        panel2KK.add(labelLocation6);
        panel2KK.add(textLocationKK);
        panel2KK.add(buttonSelect6);

        panel2KK.add(labelDate6);
        panel2KK.add(textDateKK);

        panel3KK = new JPanel();
        panel3KK.setBackground(new Color(200,120,60));
        panel3KK.setForeground(new Color(0,200,100));
        panel3KK.setBounds(0,600,1000,100);

        panel1KK.revalidate();
        panel1KK.setVisible(true);
        rentPanelField.add(panel1KK,BorderLayout.NORTH);
        rentPanelField.add(panel2KK,BorderLayout.CENTER);
        rentPanelField.add(panel3KK,BorderLayout.SOUTH);
//**********************************************************************************************************************
        tabbedPane.add("NewBuild Houses",tabbedPaneNewHouses);
        tabbedPane.add("More than 5 years old Houses",tabbedPaneOldHouses);
        tabbedPane.add("Fields",tabbedPaneField);
        tabbedPane.add("Settings",panelSettings000);
        tabbedPane.setBackground(new Color(140,140,150));
        tabbedPane.setPreferredSize(new Dimension(1000,800));
        tabbedPane.setFont(new Font(null,Font.BOLD,17));


        tabbedPaneNewHouses.add("Purchase & Sell",purchasePanelNew);
        tabbedPaneNewHouses.add("Rent",rentPanelNew);
        tabbedPaneNewHouses.setFont(new Font(null,Font.BOLD,15));
        tabbedPaneNewHouses.setBackground(new Color(140,140,150));

        tabbedPaneOldHouses.add("Purchase & Sell",purchasePanelOld);
        tabbedPaneOldHouses.add("Rent",rentPanelOld);
        tabbedPaneOldHouses.setFont(new Font(null,Font.BOLD,15));
        tabbedPaneOldHouses.setBackground(new Color(140,140,150));

        tabbedPaneField.add("Purchase & Sell",purchasePanelField);
        tabbedPaneField.add("Rent",rentPanelField);
        tabbedPaneField.setFont(new Font(null,Font.BOLD,15));
        tabbedPaneField.setBackground(new Color(140,140,150));

        this.add(tabbedPane);
        this.setLayout(new BorderLayout());
        this.add(panel0,BorderLayout.CENTER);

        panel0.setLayout(new BorderLayout());
        panel0.add(tabbedPane,BorderLayout.CENTER);
        this.setTitle("Code-ABC");

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1300,800);
        this.setLocationRelativeTo(null);
        this.setBackground(new Color(200,0,240));
        this.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {


    }
    }

