package com.company;

/*
Java Housing Project
GUI by: Seyyed Navid Zamzami. (1/3)
Controller & 1/2 Entity by: Ilia Safarian. (1/3)
Repository, Service & 1/2 Entity by: AmirSaman Taghavi Zavare. (1/3)

Professor Minoofam, Class of Sunday, 10:15 - 12:45.
Islamic Azad University, Science and Research Branch.
May, June 2022
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main implements ActionListener {
    private static JLabel userlabel;
    private static JLabel passwordlabel;
    private static JLabel success;
    private static JButton button;
    private static JPasswordField passwordText;
    private static JTextField userText;
    JFrame frame = new JFrame();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Code-ABC");
        JPanel panel = new JPanel();
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setBackground(new Color(220,140,20));
        frame.add(panel);
        panel.setLayout(null);
        //user name ****************************************************************************************************
        userlabel = new JLabel("UserID");
        userlabel.setBounds(180, 150, 130, 35);
        userlabel.setFont(new Font(null, Font.BOLD,25));
        panel.add(userlabel);
        userText = new JTextField();
        userText.setBounds(310,150, 200,35);
        userText.setBackground(new Color(140,140,160));
        userText.setForeground(new Color(50,60,150));
        userText.setFont(new Font(null,Font.BOLD,20));
        panel.add(userText);
        //password *****************************************************************************************************
        passwordlabel = new JLabel("Password");
        passwordlabel.setBounds(180, 200, 130, 35);
        passwordlabel.setFont(new Font(null, Font.BOLD,25));
        panel.add(passwordlabel);
        passwordText = new JPasswordField();
        passwordText.setBounds(310, 200, 200,35);
        passwordText.setBackground(new Color(140,140,160));
        passwordText.setFont(new Font(null,Font.BOLD,20));
        panel.add(passwordText);
        //button********************************************************************************************************
        button = new JButton("Login");
        button.setBounds(290,300,200,35);
        button.addActionListener(new Main());
        button.setBackground(new Color(50,60,150));
        button.setFont(new Font(null,Font.BOLD,25));
        button.setFocusable(false);
        frame.setLocationRelativeTo(null);
        button.setForeground(new Color(230,130,30));
        panel.add(button);
        success = new JLabel("");
        success.setFocusable(false);
        success.setBounds(240,360,300,25);
        success.setFont(new Font(null,Font.BOLD,15));
        panel.add(success);
        success.setText("");


        frame.setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {;
        String user = userText.getText();
        String password = passwordText.getText();
        if(user.equals("1111") && password.equals("1111")){
            frame.setVisible(false);
            new MyFrame();

        } else {
            success.setText("UserID or Password is not correct!");
        }
    }

    }
