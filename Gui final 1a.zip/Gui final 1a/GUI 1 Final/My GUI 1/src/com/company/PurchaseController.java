package com.company;

//purchase page controller

import com.model.entity.HousingEnti;

public class PurchaseController {
    HousingEnti housingEnti = new HousingEnti();
    PurchaseClass purchaseClass = new PurchaseClass();

    String id = purchaseClass.BuyerName.getText();
    String buyersName = purchaseClass.BuyerName.getText();
    String sellersName = purchaseClass.SellerName.getText();
    String buyerFatherName = purchaseClass.BuyerNum.getText();
    String sellerFatherName = purchaseClass.SellerNum.getText();
    String finalPrice = purchaseClass.finalprice.getText();
    String landSize = purchaseClass.textSize.getText();
    String water = purchaseClass.water.getText();
    String gas = purchaseClass.water.getText();
    String electricity = purchaseClass.electricity.getText();

    int size;
    int codeID;
    int fPrice;
    String BName;
    String SName;
    String BFName;
    String SFName;
    String wt;
    String gs;
    String el;

    public HousingEnti setHousingEnti() {

        try{
            codeID = Integer.parseInt(id);
        }
        catch (NumberFormatException e){
        }
            housingEnti.setId_Code(purchaseClass.textID.getText());

        try{
            size = Integer.parseInt(landSize);
        }
        catch (NumberFormatException e){
        }
            housingEnti.setLandSize(purchaseClass.textSize.getText());

        try {
            fPrice = Integer.parseInt(finalPrice);
        }
        catch (NumberFormatException e){
        }
            housingEnti.setFinalPrice(purchaseClass.finalprice.getText());

        try {
            BName = String.valueOf(buyersName);
        }catch (StringIndexOutOfBoundsException e){
        }
            housingEnti.setBuyersName(purchaseClass.BuyerName.getText());

        try {
            SName = String.valueOf(sellersName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersName(purchaseClass.SellerName.getText());

        try {
            BFName = String.valueOf(buyerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setBuyersFatherName(purchaseClass.BuyerNum.getText());

        try {
            SFName = String.valueOf(sellerFatherName);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setSellersFatherName(purchaseClass.SellerNum.getText());

        try{
            wt = String.valueOf(water);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setWater(purchaseClass.water.getText());

        try{
            gs = String.valueOf(gas);
        }catch (StringIndexOutOfBoundsException e){}
        housingEnti.setGas(purchaseClass.gas.getText());

        try{
            el = String.valueOf(electricity);
        }catch (StringIndexOutOfBoundsException e){
        }
        housingEnti.setElectricity(purchaseClass.electricity.getText());

        return housingEnti;
    }
}