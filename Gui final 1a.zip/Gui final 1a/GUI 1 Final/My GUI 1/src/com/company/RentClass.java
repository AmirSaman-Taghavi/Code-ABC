package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RentClass extends JFrame {
    JPanel panelFinalPurchase;
    JLabel labelID1, labelType1, labelSize1, labelPrice1, labelLocation1, labelDate1;
    JTextField textID, textType, textSize, textPrice, textLocation, textDate;
    JTextField SellerName, SellerNum, BuyerName, BuyerNum, MyName, MyNum;
    JLabel SellerLabelName,SellerLabelNum,BuyerLabelName,BuyerLabelNum, MyLabelName, MyLabelNum;
    JButton buttonBack, buttonFinal1;
    JFrame framePurchaseFinal;
    JLabel sellerSpace, buyerSpace,HouseSpace,MySpace;
    JLabel DoseWater, DoseElectricity, DoseGas;
    JTextField water, electricity, gas;
    JLabel finalprice;
    JTextField finalpricetext;

    RentClass(){
        framePurchaseFinal = new JFrame("Code-ABC Housing");
        panelFinalPurchase = new JPanel();
        framePurchaseFinal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        framePurchaseFinal.setSize(900,1000);
        framePurchaseFinal.setLocationRelativeTo(null);
        framePurchaseFinal.add(panelFinalPurchase);
        framePurchaseFinal.setBackground(new Color(200,0,240));

        panelFinalPurchase.setBackground(new Color(220,140,40));
        panelFinalPurchase.setLayout(null);

        HouseSpace = new JLabel("Rent for NewBuild House");
        HouseSpace.setBounds(200,10,600,30);
        HouseSpace.setFont(new Font(null,Font.BOLD,30));
        panelFinalPurchase.add(HouseSpace);
//ID1 *******************************************************************************************************************
        labelID1 = new JLabel("ID");
        labelID1.setBounds(10,60,20,25);
        labelID1.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(labelID1);

        textID = new JTextField();
        textID.setBounds(40,60,70,22);
        textID.setBackground(new Color(140,140,160));
        textID.setForeground(new Color(40,50,150));
        panelFinalPurchase.add(textID);
//Type1 *****************************************************************************************************************
        labelType1 = new JLabel("Type");
        labelType1.setBounds(130,60,100,25);
        labelType1.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(labelType1);

        textType = new JTextField();
        textType.setBounds(235,60,200,22);
        textType.setBackground(new Color(140,140,160));
        textType.setForeground(new Color(40,50,150));
        panelFinalPurchase.add(textType);
//Size1 *****************************************************************************************************************
        labelSize1 = new JLabel("Size(m^2)");
        labelSize1.setBounds(450,60,130,25);
        labelSize1.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(labelSize1);

        textSize = new JTextField();
        textSize.setBounds(590,60,150,22);
        textSize.setBackground(new Color(140,140,160));
        textSize.setForeground(new Color(40,50,150));
        panelFinalPurchase.add(textSize);
//Price1 ****************************************************************************************************************
        labelPrice1 = new JLabel("Price(Million)");
        labelPrice1.setBounds(10,110,50,25);
        labelPrice1.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(labelPrice1);

        textPrice = new JTextField();
        textPrice.setBounds(70,110,200,22);
        textPrice.setBackground(new Color(140,140,160));
        textPrice.setForeground(new Color(40,50,150));
        panelFinalPurchase.add(textPrice);
//Date1 *****************************************************************************************************************
        labelDate1 = new JLabel("Recent time of Edition");
        labelDate1.setBounds(280,110,250,25);
        labelDate1.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(labelDate1);

        textDate = new JTextField();
        textDate.setBounds(540,110,200,22);
        textDate.setBackground(new Color(140,140,160));
        textDate.setForeground(new Color(40,50,150));
        panelFinalPurchase.add(textDate);
//Location *************************************************************************************************************
        labelLocation1 = new JLabel("Location");
        labelLocation1.setBounds(10,160,120,25);
        labelLocation1.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(labelLocation1);

        textLocation = new JTextField();
        textLocation.setBounds(110,160,740,22);
        textLocation.setBackground(new Color(140,140,160));
        textLocation.setForeground(new Color(40,50,150));
        panelFinalPurchase.add(textLocation);
// Seller **************************************************************************************************************
        sellerSpace = new JLabel("Seller:");
        sellerSpace.setBounds(10,210,190,25);
        sellerSpace.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(sellerSpace);

        SellerLabelName = new JLabel("Name");
        SellerLabelName.setBounds(10,260,190,25);
        SellerLabelName.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(SellerLabelName);

        SellerName = new JTextField();
        SellerName.setBackground(new Color(150,140,160));
        SellerName.setForeground(new Color(40,50,150));
        SellerName.setBounds(210,260,200,20);
        panelFinalPurchase.add(SellerName);

        SellerLabelNum  = new JLabel("Father's Name");
        SellerLabelNum.setBounds(10,310,160,25);
        SellerLabelNum.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(SellerLabelNum);

        SellerNum = new JTextField();
        SellerNum.setBackground(new Color(140,140,160));
        SellerNum.setForeground(new Color(40,50,150));
        SellerNum.setBounds(180,310,200,20);
        panelFinalPurchase.add(SellerNum);
// Buyer ***************************************************************************************************************
        buyerSpace = new JLabel("Purchaser:");
        buyerSpace.setBounds(10,360,190,25);
        buyerSpace.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(buyerSpace);

        BuyerLabelName = new JLabel("Name");
        BuyerLabelName.setBounds(10,410,190,25);
        BuyerLabelName.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(BuyerLabelName);

        BuyerName = new JTextField();
        BuyerName.setBackground(new Color(150,140,160));
        BuyerName.setForeground(new Color(40,50,150));
        BuyerName.setBounds(210,410,200,20);
        panelFinalPurchase.add(BuyerName);

        BuyerLabelNum  = new JLabel("Father's Name");
        BuyerLabelNum.setBounds(10,450,160,25);
        BuyerLabelNum.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(BuyerLabelNum );

        BuyerNum = new JTextField();
        BuyerNum.setBackground(new Color(140,140,160));
        BuyerNum.setForeground(new Color(40,50,150));
        BuyerNum.setBounds(180,450,200,20);
        panelFinalPurchase.add(BuyerNum);
//Me ******************************************************************************************************************
        MySpace = new JLabel("Owner of Housing:");
        MySpace.setBounds(10,500,190,25);
        MySpace.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(MySpace);

        MyLabelName = new JLabel("Name");
        MyLabelName.setBounds(10,550,190,25);
        MyLabelName.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(MyLabelName);

        MyName = new JTextField();
        MyName.setBackground(new Color(150,140,160));
        MyName.setForeground(new Color(40,50,150));
        MyName.setBounds(210,550,200,20);
        panelFinalPurchase.add(MyName);

        MyLabelNum  = new JLabel("Father's Name");
        MyLabelNum .setBounds(10,590,160,25);
        MyLabelNum .setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(MyLabelNum  );

        MyNum = new JTextField();
        MyNum.setBackground(new Color(140,140,160));
        MyNum.setForeground(new Color(40,50,150));
        MyNum.setBounds(180,590,200,20);
        panelFinalPurchase.add(MyNum);
// Equipment ***********************************************************************************************************
        DoseWater = new JLabel("Dose have Water?");
        DoseWater.setBounds(450,200,220,25);
        DoseWater.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(DoseWater);

        water = new JTextField();
        water.setBackground(new Color(140,140,160));
        water.setForeground(new Color(40,50,150));
        water.setBounds(640,200,70,20);
        panelFinalPurchase.add(water);

        DoseElectricity = new JLabel("Dose have Electricity?");
        DoseElectricity.setBounds(450,240,220,25);
        DoseElectricity.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(DoseElectricity );

        electricity = new JTextField();
        electricity.setBackground(new Color(140,140,160));
        electricity.setForeground(new Color(40,50,150));
        electricity.setBounds(670,240,70,20);
        panelFinalPurchase.add(electricity);

        DoseGas = new JLabel("Dose have Gas?");
        DoseGas.setBounds(450,280,220,25);
        DoseGas.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(DoseGas);

        gas = new JTextField();
        gas.setBackground(new Color(140,140,160));
        gas.setForeground(new Color(40,50,150));
        gas.setBounds(625,280,70,20);
        panelFinalPurchase.add(gas);

        finalprice =new JLabel("Final Price(Million):");
        finalprice.setBounds(450,500,220,25);
        finalprice.setFont(new Font(null,Font.BOLD,20));
        panelFinalPurchase.add(finalprice);

        finalpricetext = new JTextField();
        finalpricetext.setBackground(new Color(140,140,160));
        finalpricetext.setForeground(new Color(40,50,150));
        finalpricetext.setBounds(640,500,170,20);
        panelFinalPurchase.add(finalpricetext);
//Buttons **************************************************************************************************************

        buttonBack = new JButton("Go Back");
        buttonBack.setBackground(new Color(50,60,150));
        buttonBack.setForeground(new Color(230,130,30));
        buttonBack.setBounds(50,700,150,25);
        buttonBack.setFocusable(false);
        buttonBack.setFont(new Font(null,Font.BOLD,20));
        buttonBack.setVisible(true);
        panelFinalPurchase.add(buttonBack);
        buttonBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                framePurchaseFinal.setVisible(false);
                framePurchaseFinal.dispose();

            }
        });
        buttonFinal1 = new JButton("Finish");
        buttonFinal1.setBackground(new Color(50,60,150));
        buttonFinal1.setForeground(new Color(230,130,30));
        buttonFinal1.setBounds(550,700,150,25);
        buttonFinal1.setFocusable(false);
        buttonFinal1.setFont(new Font(null,Font.BOLD,20));
        buttonFinal1.setVisible(true);
        panelFinalPurchase.add(buttonFinal1);
        buttonFinal1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selection = JOptionPane.showConfirmDialog(null, "Do you want this deal done?", "confirm", JOptionPane.YES_NO_OPTION);

                if(selection==JOptionPane.YES_OPTION){
                    framePurchaseFinal.setVisible(false);
                    framePurchaseFinal.dispose();
                    JOptionPane.showMessageDialog(null,"Purchase Finished Successfully!");
                }
            }
        });

        framePurchaseFinal.setVisible(true);
    }
}
