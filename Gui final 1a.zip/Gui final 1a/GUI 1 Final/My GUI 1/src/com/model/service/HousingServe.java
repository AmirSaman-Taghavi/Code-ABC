package com.model.service;

//service

import com.model.entity.HousingEnti;
import com.model.repository.HousingRepo;

public class HousingServe {
    public void connect() throws Exception{
        try(HousingRepo housingRepo = new HousingRepo()) {
            housingRepo.Housing();
            housingRepo.commit();
        }
    }

    public void entity_Dependency() throws Exception{
        try(HousingRepo housingRepo = new HousingRepo()) {
            housingRepo.dependency();
            housingRepo.commit();
        }
    }
    public void palace() throws Exception{
        try(HousingRepo housingRepo = new HousingRepo()) {
            housingRepo.groundsAndHouses();
            housingRepo.commit();
        }
    }

    public void process() throws Exception{
        try(HousingRepo housingRepo = new HousingRepo()) {
            housingRepo.contractsAndTransactions(new HousingEnti());
            housingRepo.commit();
        }
    }

    public void realStatePerson() throws Exception {
        try(HousingRepo housingRepo = new HousingRepo()) {
            housingRepo.responsible();
            housingRepo.commit();
        }
    }

    public void documentation() throws Exception{
        try(HousingRepo housingRepo = new HousingRepo()) {
            housingRepo.documents();
            housingRepo.commit();
        }
    }
}