package com.model.entity;

//entity

public class HousingEnti{
    private String id_Code;
    private String agent_Password;
    private String land_Type;
    private String registeredContract;
    private String finalPrice;
    private String people_Data;
    private String people_Time;
    private String buyersNationalCode;
    private String buyersFatherName;
    private String buyersName;
    private String sellersNationalCode;
    private String sellersFatherName;
    private String sellersName;
    private String process_Completed;
    private String landLocation;
    private String landSize;
    private String agentName;
    private String agentFatherName;
    private String fiveYearPrice_land_Type;
    private String fiveYearPrice;
    private String fiveYearLocation;
    private String fiveYearDate;
    private String fiveLandSize;
    private String water;
    private String gas;
    private String electricity;
    private String rentPrice;
    private String rentSize;
    private String rentLocation;



    public String getId_Code() {
        return id_Code;
    }

    public HousingEnti setId_Code(String id_Code) {
        this.id_Code = id_Code;
        return this;
    }

    public String getAgent_Password() {
        return agent_Password;
    }

    public HousingEnti setAgent_Password(String agent_Password) {
        this.agent_Password = agent_Password;
        return this;
    }

    public String getLand_Type() {
        return land_Type;
    }

    public HousingEnti setLand_Type(String land_Type) {
        this.land_Type = land_Type;
        return this;
    }

    public String getRegisteredContract() {
        return registeredContract;
    }

    public HousingEnti setRegisteredContract(String registeredContract) {
        this.registeredContract = registeredContract;
        return this;
    }

    public String getFinalPrice() {
        return finalPrice;
    }

    public HousingEnti setFinalPrice(String finalPrice) {
        this.finalPrice = finalPrice;
        return this;
    }

    public String getSellersNationalCode() {
        return sellersNationalCode;
    }

    public HousingEnti setSellersNationalCode(String sellersNationalCode) {
        this.sellersNationalCode = sellersNationalCode;
        return this;
    }

    public String getSellersFatherName() {
        return sellersFatherName;
    }

    public HousingEnti setSellersFatherName(String sellersFatherName) {
        this.sellersFatherName = sellersFatherName;
        return this;
    }

    public String getProcess_Completed() {
        return process_Completed;
    }

    public HousingEnti setProcess_Completed(String process_Completed) {
        this.process_Completed = process_Completed;
        return this;
    }

    public String getBuyersNationalCode() {
        return buyersNationalCode;
    }

    public HousingEnti setBuyersNationalCode(String buyersNationalCode) {
        this.buyersNationalCode = buyersNationalCode;
        return this;
    }

    public String getBuyersFatherName() {
        return buyersFatherName;
    }

    public HousingEnti setBuyersFatherName(String buyersFatherName) {
        this.buyersFatherName = buyersFatherName;
        return this;
    }

    public String getPeople_Data() {
        return people_Data;
    }

    public HousingEnti setPeople_Data(String people_Data) {
        this.people_Data = people_Data;
        return this;
    }

    public String getPeople_Time() {
        return people_Time;
    }

    public HousingEnti setPeople_Time(String people_Time) {
        this.people_Time = people_Time;
        return this;
    }

    public String getFiveYearPrice_land_Type() {
        return fiveYearPrice_land_Type;
    }

    public HousingEnti setFiveYearPrice_land_Type(String fiveYearPrice_land_Type) {
        this.fiveYearPrice_land_Type = fiveYearPrice_land_Type;
        return this;
    }

    public String getFiveYearPrice() {
        return fiveYearPrice;
    }

    public HousingEnti setFiveYearPrice(String fiveYearPrice) {
        this.fiveYearPrice = fiveYearPrice;
        return this;
    }

    public String getBuyersName() {
        return buyersName;
    }

    public HousingEnti setBuyersName(String buyersName) {
        this.buyersName = buyersName;
        return this;
    }

    public String getSellersName() {
        return sellersName;
    }

    public HousingEnti setSellersName(String sellersName) {
        this.sellersName = sellersName;
        return this;
    }

    public String getLandLocation() {
        return landLocation;
    }

    public HousingEnti setLandLocation(String landLocation) {
        this.landLocation = landLocation;
        return this;
    }

    public String getFiveYearLocation() {
        return fiveYearLocation;

    }

    public HousingEnti setFiveYearLocation(String fiveYearLocation) {
        this.fiveYearLocation = fiveYearLocation;
        return this;
    }

    public String getLandSize() {
        return landSize;
    }

    public HousingEnti setLandSize(String landSize) {
        this.landSize = landSize;
        return this;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getAgentFatherName() {
        return agentFatherName;
    }

    public void setAgentFatherName(String agentFatherName) {
        this.agentFatherName = agentFatherName;
    }

    public String getFiveYearDate() {
        return fiveYearDate;
    }

    public HousingEnti setFiveYearDate(String fiveYearDate) {
        this.fiveYearDate = fiveYearDate;
        return this;
    }

    public String getFiveLandSize() {
        return fiveLandSize;
    }

    public HousingEnti setFiveLandSize(String fiveLandSize) {
        this.fiveLandSize = fiveLandSize;
        return this;
    }

    public String getWater() {
        return water;
    }

    public void setWater(String water) {
        this.water = water;
    }

    public String getGas() {
        return gas;
    }

    public void setGas(String gas) {
        this.gas = gas;
    }

    public String getElectricity() {
        return electricity;
    }

    public void setElectricity(String electricity) {
        this.electricity = electricity;
    }

    public String getRentPrice() {
        return rentPrice;
    }

    public void setRentPrice(String rentPrice) {
        this.rentPrice = rentPrice;
    }

    public String getRentSize() {
        return rentSize;
    }

    public void setRentSize(String rentSize) {
        this.rentSize = rentSize;
    }

    public String getRentLocation() {
        return rentLocation;
    }

    public void setRentLocation(String rentLocation) {
        this.rentLocation = rentLocation;
    }
}
